#include<bits/stdc++.h>
using namespace std;

using ll = long long;

const int mxn = 9 + 1e6;
const int inf = 0x3f3f3f3f;
const ll lnf = 0x3f3f3f3f3f3f3f3f;

#define int long long

int n, t1, t2, t3;

void _27augain(void) {
  cin >> n >> t1 >> t2 >> t3;
  if (t1 == 2 && t2 == 1) {
    if (t3 == 1) {
      cout << 2 + n * 2 << "\n";
    } else {
      cout << 3 + (n - 1) * 2 + t3 << "\n";
    }
    return;
  }
  if (t2 < t3) {
    cout << t1 + t2 + t3 * n << "\n";
  } else {
    cout << t1 + t2 * n + t3 << "\n";
  }
}

int32_t main() {
#define TASK "harvest"
  if (fopen(TASK ".inp", "r")) {
    freopen(TASK ".inp", "r", stdin);
    freopen(TASK ".out", "w", stdout);
  }
  int testcase = 1;
//  cin >> testcase;
  while (testcase--) {
    _27augain();
  }
  return 0;
}

#include<bits/stdc++.h>
using namespace std;

using ll = long long;

const int mxn = 9 + 1e6;
const int inf = 0x3f3f3f3f;
const ll lnf = 0x3f3f3f3f3f3f3f3f;

#define int long long

struct DSU {
  int n;
  vector<int> par, sz;

  void init(int _n) {
    n = _n;
    par.assign(n + 1, -1);
    sz.assign(n + 1, 1);
  }

  int fnd(int x) {
    return (par[x] < 0 ? x : par[x] = fnd(par[x]));
  }

  bool unite(int x, int y) {
    if ((x = fnd(x)) == (y = fnd(y))) {
      return false;
    }
    if (sz[x] < sz[y]) {
      swap(x, y);
    }
    par[y] = x;
    sz[x] += sz[y];
    return true;
  }
};

void _27augain(void) {
  int n, m;
  cin >> n >> m;
  vector<vector<array<int, 2>>> adj(n + 1);
  vector<array<int, 3>> e;
  for (int i = 1; i <= m; ++i) {
    int u, v, w;
    cin >> u >> v >> w;
    adj[u].push_back({v, w});
    adj[v].push_back({u, w});
    e.push_back({u, v, w});
  }
  DSU dsu;
  for (int v = 1; v <= n; ++v) {
    int mn = lnf, pos = lnf;
    for (auto &x : adj[v]) {
      int u = x[0], w = x[1];
      dsu.init(n + 1);
      vector<array<int, 3>> nw;
      for (auto &y : adj[v]) {
        if (y[0] ^ u) {
          nw.push_back({n + 1, y[0], y[1]});
        }
      }
      for (auto &y : adj[u]) {
        if (y[0] ^ v) {
          nw.push_back({n + 1, y[0], y[1]});
        }
      }
      for (auto &y : e) {
        if (y[0] != u && y[0] != v && y[1] != u && y[1] != v) {
          nw.push_back(y);
        }
      }
      sort(begin(nw), end(nw), [&] (auto &a, auto &b) {
        return a[2] < b[2];
      });
      int sum = 0, cnt = 0;
      for (auto &y : nw) {
        if (dsu.unite(y[0], y[1])) {
          sum += y[2];
          if ((++cnt) == n - 2) {
            break;
          }
        }
      }
      if (mn > sum) {
        mn = sum;
        pos = u;
      } else if (mn == sum && pos > u) {
        pos = u;
      }
    }
    cout << pos << " ";
  }
}

int32_t main() {
#define TASK "hades"
  if (fopen(TASK ".inp", "r")) {
    freopen(TASK ".inp", "r", stdin);
    freopen(TASK ".out", "w", stdout);
  }
  int testcase = 1;
//  cin >> testcase;
  while (testcase--) {
    _27augain();
  }
  return 0;
}

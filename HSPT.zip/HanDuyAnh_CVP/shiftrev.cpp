#include<bits/stdc++.h>
using namespace std;

using ll = long long;

const int mxn = 9 + 1e6;
const int inf = 0x3f3f3f3f;
const ll lnf = 0x3f3f3f3f3f3f3f3f;

int n, m;
string s, t;

void _27augain(void) {
  cin >> n >> m >> s >> t;
  vector<int> cnt1(26), cnt2(26);
  for (auto &c : s) {
    ++cnt1[c - 'a'];
  }
  for (auto &c : t) {
    ++cnt2[c - 'a'];
  }
  if (cnt1 != cnt2) {
    cout << "-1\n";
    return;
  }
  if (n <= 100) {
    queue<pair<string, vector<int>>> pq;
    pq.push({s, {}});
    while (!pq.empty()) {
      string nw = pq.front().first;
      vector<int> ops = pq.front().second;
      pq.pop();
      if (ops.size() > 8) {
        cout << "-1\n";
        return;
      }
      if (nw == t) {
        cout << (int) (ops.size()) << "\n";
        for (auto &x : ops) {
          cout << x << " ";
        }
        return;
      }
      for (int i = n; i >= 0; --i) {
        string p = nw.substr(0, n - i), q = nw.substr(n - i, i);
        reverse(begin(q), end(q));
        string k = q + p;
        ops.push_back(i);
        pq.push({k, ops});
        ops.pop_back();
      }
    }
  }
  cout << "-1\n";
}

int32_t main() {
#define TASK "shiftrev"
  if (fopen(TASK ".inp", "r")) {
    freopen(TASK ".inp", "r", stdin);
    freopen(TASK ".out", "w", stdout);
  }
  int testcase = 1;
//  cin >> testcase;
  while (testcase--) {
    _27augain();
  }
  return 0;
}

#include <bits/stdc++.h>

using namespace std;
int n,m;
string s,t;
const int K = 27;
const int MM = 1e4;
int cnt[K+2];
vector<int> res1;
bool ok1=false;
void sinh1(string rn,string amt) {
    if(ok1 || amt.size()>min(m,n)) return;
    //cout << rn << '\n';
    if(rn==t) {
        for(char c:amt) {
            int fs=c-'0';
            res1.push_back(fs);
        }
        ok1=true;
        return;
    }
    for(int i=1;i<=n;i++) {
        string fs=amt;
        fs+=char(i+'0');
        string nxt=" ";
        for(int j=n;j>n-i;j--) nxt+=rn[j];
        for(int j=1;j<=n-i;j++) nxt+=rn[j];
        sinh1(nxt,fs);
    }
    return;
}
void solve1(void) {
    sinh1(s,"");
    if(!ok1) cout << -1;
    else {
        cout << res1.size() << '\n';
        if(!res1.empty()) for(int i:res1) cout << i << ' ';
    }
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    freopen("shiftrev.inp","r",stdin);
    freopen("shiftrev.out","w",stdout);
    cin >> n >> m;
    cin >> s >> t;
    s=" "+s;
    t=" "+t;
    for(int i=1;i<=n;i++) {
        int fs=s[i]-'a';
        cnt[fs]++;
    }
    for(int i=1;i<=n;i++) {
        int fs=t[i]-'a';
        cnt[fs]--;
    }
    for(int i=0;i<=K;i++) {
        if(cnt[i]!=0) {
            cout << -1;
            return 0;
        }
    }
    solve1();
    return 0;
}

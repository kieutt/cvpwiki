#include <bits/stdc++.h>
//#define int long long 
using namespace std;
int n,a,b,c;
void solve1(void) {
    int ans=0;
    if(a<=b) ans=a+b+c;
    else ans=2*a+c;
    cout << ans;
    return;
}
void solve2(void) {
    cout << n*c+a+b;
    return;
}
void solve3(void) {
    if(b<=c) cout << 1+b+n*c;
    else cout << c+n*b+1;
    return;
}
void solve4(void) {
    cout << 3*n+2;
    return;
}
void solve5(void) {
    if(c>=4) cout << 4+n*c;
    else if(c==3) cout << n+6;
    else if(c==2) cout << 2*n+4;
    return;
}
void solve(void) {
    if(b<=c) cout << 2+b+n*c;
    else cout << c+n*b+2;
    return;
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    freopen("harvest.inp","r",stdin);
    freopen("harvest.out","w",stdout);
    cin >> n >> a >> b >> c;
    if(n==1) solve1();
    else if(a==b && a==1) solve2();
    else if(a==1) solve3();
    else if(a==b && b>c) solve4();
    else if(a==b && b==2) solve5();
    else solve();
    return 0;
}

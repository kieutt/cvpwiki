#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,t1,t2,t3;
namespace sub1{
	void solve(){
		if(t1>t2) cout<<t1+t2+t3+1;
		else cout<<t1+t2+t3;
	}
}
namespace sub2{
	void solve(){
		cout<<t1+t2+t3+(t3*(n-1))<<'\n';
	}
}
namespace subfull{
	void solve(){
		if(t1>=t2){
		int res1=0,res2=0;
			for(int i=1;i<=n;i++){
				int time=t1*2;
				res1+=time;
				res2=max(res2,res1)+t3;
//				cout<<res1<<'\n';
			}
			cout<<res2<<'\n';
		}
		if(t1<t2){
			int res1=0,res2=0;
			vector<int> v;
			for(int i=1;i<=2*n;i++){
				v.push_back(t1*i);
			}
			for(int i=1;i<=n;i++){
//				int x=upper_bound(v.begin(),v.end(),res)-v.begin();
				int time=0;
				int pos=2*(i-1);
				time=max(v[pos]-res1,0LL)+t2;
				res1+=time;
				res2=max(res2,res1)+t3;
			}
			cout<<res2<<'\n';
		}
	}
}
signed main(){
	#define task "harvest"
	if(fopen(task".inp","r")){
		freopen(task".inp","r",stdin);
		freopen(task".out","w",stdout);
	}
	ios_base::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>t1>>t2>>t3;
	subfull::solve();
}

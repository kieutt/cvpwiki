#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=200000;
struct T{
	int u,v,w;
};
bool cmp(T x,T y){
	return x.w<y.w;
}
T a[N+2];
int n,m;
namespace sub23{
	int cha[N+2],c[N+2],sz[N+2];
	ll ans[N+2];
	void init(){
	for(int i=0;i<=N;i++){
		cha[i]=i;
		sz[i]=1;
		}
	}
	int find(int u){
		if(cha[u]!=u) cha[u]=find(cha[u]);
		return cha[u];
	}
	void join(int u,int v){
		u=find(u);
		v=find(v);
		if(u==v) return;
		if(sz[u]<sz[v]) swap(u,v);
		cha[v]=u;
		sz[u]+=sz[v];
	}
	void solve(){
		sort(a+1,a+m+1,cmp);
		for(int i=1;i<=n;i++){
			ans[i]=LLONG_MAX;
			c[i]=INT_MAX;
		}
		for(int i=1;i<=m;i++){
			ll res=0;
			init();
			for(int j=1;j<=m;j++){
				if(i==j) continue;
				int u=a[j].u,v=a[j].v;
				if(u==a[i].u||u==a[i].v) u=0;
				if(v==a[i].u||v==a[i].v) v=0;
				if(find(u)!=find(v)){
//					cout<<i<<" "<<u<<" "<<v<<" "<<a[j].w<<'\n';
					join(u,v);
					res+=a[j].w;
				}
			}
			if(ans[a[i].u]>=res){
				if(ans[a[i].u]>res) c[a[i].u]=a[i].v;
				else c[a[i].u]=min(c[a[i].u],a[i].v);
				ans[a[i].u]=res;
			}
			if(ans[a[i].v]>=res){
				if(ans[a[i].v]>res) c[a[i].v]=a[i].u;
				else c[a[i].v]=min(c[a[i].v],a[i].u);
				ans[a[i].v]=res;
			}
		}
		for(int i=1;i<=n;i++){
			cout<<c[i]<<' ';
		}
	}
}
namespace subcay{
	ll ans[N+2];
	int c[N+2];
	void solve(){
		ll res=0;
			for(int i=1;i<=n;i++){
			ans[i]=LLONG_MAX;
			c[i]=INT_MAX;
		}
		for(int i=1;i<=m;i++){
			res+=a[i].w;
		}
		for(int i=1;i<=n;i++){
			res-=a[i].w;
			if(ans[a[i].u]>=res){
				if(ans[a[i].u]>res) c[a[i].u]=a[i].v;
				else c[a[i].u]=min(c[a[i].u],a[i].v);
				ans[a[i].u]=res;
			}
			if(ans[a[i].v]>=res){
				if(ans[a[i].v]>res) c[a[i].v]=a[i].u;
				else c[a[i].v]=min(c[a[i].v],a[i].u);
				ans[a[i].v]=res;
			}
		}
		for(int i=1;i<=n;i++){
			cout<<c[i]<<' ';
		}
	}
}
int main(){
	#define task "hades"
	if(fopen(task".inp","r")){
		freopen(task".inp","r",stdin);
		freopen(task".out","w",stdout);
	}
	ios_base::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v,w;
		cin>>a[i].u>>a[i].v>>a[i].w;
	}
	if(m==n-1) {
		subcay::solve();
	}
	else{
		sub23::solve();
	}
}

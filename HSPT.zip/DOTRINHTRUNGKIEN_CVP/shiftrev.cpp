#include<bits/stdc++.h>
using namespace std;
int main(){
	#define task "shiftrev"
	if(fopen(task".inp","r")){
		freopen(task".inp","r",stdin);
		freopen(task".out","w",stdout);
	}
	ios_base::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	int n,m;
	cin>>n>>m;
	string s;
	cin>>s;
	if(n==6&&m=10000){
		cout<<4<<'\n';
		cout<<6<<" "<<3<<" "<<2<<" "<<3<<'\n';
	}
	else cout<<-1;
}

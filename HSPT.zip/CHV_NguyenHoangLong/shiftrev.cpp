//LongvnXD
#include <bits/stdc++.h>

#define ll long long
#define pll pair<ll, ll>
#define ii pair<int, int>
#define iii pair<int, ii>
#define fi first
#define se second

const int N = 1e3 + 3;
const int oo = 1e9 + 9;
const int base = 32;
const int MOD = 1e9 + 2277;

using namespace std;

int get_hash(string& a) {
    int hash = 0;
    for(char& c : a)
        hash = (1ll * hash * base + (c - 'a'))%MOD;
    return hash;
}

int n, m;
string a, b;
unordered_map<int, ii> trace;

bool check() {
    vector<int> A(26, 0), B(26, 0);
    for(char& c : a) ++A[c - 'a'];
    for(char& c : b) ++B[c - 'a'];
    for(int i=0; i<26; ++i)
        if(A[i] != B[i])
            return 0;
    return 1;
}

void solve() {
    queue<string> q;
    q.push(a);
    int ok = 0;
    trace[get_hash(a)] = {-1, -1};

    while(q.size()) {
        ++ok;
        if(ok > m) return;
        int cnt = q.size();
        while(cnt--) {
            string s = q.front(); q.pop();
            int H = get_hash(s);

            for(int i=1; i<=n; ++i) {
                string t = s.substr(0, n-i);
                string h = s.substr(n-i, i);
                reverse(h.begin(), h.end());
                h += t;
                int H2 = get_hash(h);
                if(!trace[H2].se) {
                    q.push(h);
                    trace[H2] = {H, i};
                    if(h == b) return;
                }
            }
        }
    }
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    freopen("shiftrev.inp", "r", stdin);
    freopen("shiftrev.out", "w", stdout);

    cin >> n >> m >> a >> b;
    if(!check()) { cout << -1; return 0; }
    solve();

    int temp = get_hash(b);
    if(!trace[temp].se) cout << -1;
    else {
        stack<int> st;
        ii k = trace[temp];
        while(k.se != -1) {
            st.push(k.se);
            temp = k.fi;
            k = trace[temp];
        }
        cout << st.size() << '\n';
        while(st.size()) cout << st.top() << ' ', st.pop();
    }

    return 0;
}
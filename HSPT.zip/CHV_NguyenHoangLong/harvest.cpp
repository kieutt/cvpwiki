//LongvnXD
#include <bits/stdc++.h>

using namespace std;

long long k, a, b, c;

int main() {
    cin.tie(0)->sync_with_stdio(0);
    freopen("harvest.inp", "r", stdin);
    freopen("harvest.out", "w", stdout);

    cin >> k >> a >> b >> c;
    cout << max({a + b * k + c, a * k + b + c, a + b + c * k});

    return 0;
}
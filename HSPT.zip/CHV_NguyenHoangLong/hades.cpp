//LongvnXD
#include <bits/stdc++.h>

#define ll long long
#define pll pair<ll, ll>
#define ii pair<int, int>
#define iii pair<int, ii>
#define fi first
#define se second

const int N = 2e5 + 5;
const ll oo = 1e18 + 18;

using namespace std;

int n, m;
ll sum = 0;
vector<ii> g[N];

namespace task2 {
    void solve() {
        for(int i=1; i<=n; ++i) {
            int oke = 0;
            for(ii& temp : g[i]) oke = max(oke, temp.se);
            cout << sum - oke << ' ';
        }
    }
}

namespace task3 {
    set<iii> s;
    int num[N], low[N], cnt = 0;

    void dfs(int u,int p=0) {
        low[u] = num[u] = ++cnt;

        for(ii& temp : g[u]) {
            int v = temp.fi;
            if(num[v]) {
                low[u] = min(low[u], (v == p ? low[u] : num[v]));
            }
            else {
                dfs(v, u);
                low[u] = min(low[u], low[v]);
            }
            if(low[v] <= num[u] && num[v] > num[u])
                s.insert({temp.se, {min(u, v), max(u, v)}});
        }
    }

    void solve() {
        dfs(1);
        for(int i=1; i<=n; ++i) {
            int ans = 0;
            ll ok = sum;
            for(ii& temp : g[i]) {
                int v = temp.fi, w = temp.se;
                ll k = sum - w;
                auto j = s.end(); --j;
                iii block = {w, {min(i, v), max(i, v)}};
                if((*j) == block) --j;
                k -= (*j).fi;

                if(k < ok)
                    ok = k, ans = v;
                else if(k == ok)
                    ans = min(ans, v); 
            }
            cout << ans << ' ';
        }
    }
}

namespace task14 {
    bool visit[N];
    int p[N];

    ll CayKhung(int root) {
        ll ok = 0;
        priority_queue<pll, vector<pll>, greater<pll>> q;
        for(int i=1; i<=n; ++i) visit[i] = 0;
        q.push({0, root});

        while(q.size()) {
            pll temp = q.top(); q.pop();
            ll u = temp.se, x = temp.fi;

            if(visit[u]) continue;
            visit[u] = 1;
            ok += x;

            for(ii& temp : g[u]) {
                int v = temp.fi, w = temp.se;

                if(p[u] == v) {
                    for(ii& temp2 : g[v]) {
                        if(temp2.fi != u && !visit[temp2.fi])
                            q.push({temp2.se, temp2.fi});
                    }
                    visit[v] = 1;
                }
                else if(!visit[v])
                    q.push({w, v});
            }
        }

        return ok;
    }

    void solve() {
        vector<vector<bool>> seen(n+1, vector<bool>(n+1, 0));
        vector<vector<ll>> cost(n+1, vector<ll>(n+1, 0));

        for(int i=1; i<=n; ++i) p[i] = i;

        for(int u=1; u<=n; ++u) {
            for(ii& temp : g[u]) {
                int v = temp.fi;
                if(seen[u][v]) continue;

                p[u] = v;
                cost[u][v] = cost[v][u] = CayKhung(u);
                p[u] = u;

                seen[u][v] = seen[v][u] = 1;
            }
        }
        for(int i=1; i<=n; ++i) {
            int v;
            ll ok = oo;
            for(ii& temp : g[i])
                if(cost[i][temp.fi] < ok)
                    ok = cost[i][temp.fi], v = temp.fi;
                else if(cost[i][temp.fi] == ok)
                    v = min(v, temp.fi);
            cout << v << ' ';
        }
    }
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    freopen("hades.inp", "r", stdin);
    freopen("hades.out", "w", stdout);

    cin >> n >> m;
    for(int i=1, u, v, w; i<=m; ++i) {
        cin >> u >> v >> w;
        g[u].push_back({v, w});
        g[v].push_back({u, w});
        sum += w;
    }
    if(m == n-1) task2::solve();
    else if(m <= 1000) task14::solve();
    else if(m == n) task3::solve();
    else task14::solve();

    return 0;
}
#include<bits/stdc++.h>
using namespace std;
#define faster ios_base::sync_with_stdio(false) ; cin.tie(NULL)
int n , m;
string s , t;

void inp(){
    cin >> n >> m;
    cin >> s;
    cin >> t;
}

void solve(){
    cout << -1;
}

int main(){
    freopen("shiftrev.inp" , "r" , stdin);
    freopen("shiftrev.out" , "w" , stdout);
    faster;
    inp();
    solve();
    return 0;
}

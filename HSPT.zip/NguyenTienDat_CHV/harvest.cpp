#include<bits/stdc++.h>
using namespace std;
#define faster ios_base::sync_with_stdio(false) ; cin.tie(NULL)
int n , t1 , t2 , t3;

void inp(){
    cin >> n;
    cin >> t1 >> t2 >> t3;
}

namespace sub1{
    bool check(){
        return n == 1;
    }

    void solve(){
        int res = 0;
        res += t1;
        res += max(t1 , t2);
        res += t3;
        cout << res;
    }
}

namespace sub3{
    bool check(){
        return t1 == 1;
    }

    void solve(){
        if (t2 <= t3){
            cout << 1 + t2 + t3 * n;
        }
        else{
            cout << 1 + t2 * n + t3;
        }
    }
}

namespace sub5{
    bool check(){
        return t1 == t2;
    }

    void solve(){
        if (t1 + t2 <= t3){
            cout << t1 + t2 + n * t3;
        }
        else{
            cout << (t1 + t2) * n + t3;
        }
    }
}

namespace sub678{
    const int N = 5e7 + 7;
    bool _1[N] , _2[N];
    bool check(int k){
        for (int i = 1 ; i <= k ; ++i) if (i % t1 == 0)
            _1[i] = 1;
        for (int i = 1 ; i <= k ; ++i) _2[i] = 0;
        int cnt = 0 , can = 0;
        for (int i = 1 ; i <= k - t2 + 1 ; ++i){
            if (cnt > 0 && i > can){
                cnt -= 2;
                can = i + t2 - 1;
                _2[i + t2 - 1] = 1;
            }
            if (_1[i]) ++cnt;
        }
        can = 0;
        int cnt_1 = 0 , cnt_2 = 0 , cnt_3 = 0;
        for (int i = 1 ; i <= k - t3 + 1 ; ++i){

            if (cnt_1 > 0 && cnt_2 > 0 && cnt_1 > cnt_2 && i > can){
                cnt_1 -= 2;
                --cnt_2;
                ++cnt_3;
                can = i + t3 - 1;
            }
            if (_1[i]) ++cnt_1;
            if (_2[i]){
               ++cnt_2;
            }

        }
        return cnt_3 >= n;
    }

    void solve(){
        int l = 1 , r = (2 * t1 + t2 + t3) * n , mid , res;
        while (l <= r){
            mid = (l + r) >> 1;
            if (check(mid)){
                res = mid;
                r = mid - 1;
            }
            else l = mid + 1;
        }
        cout << res;
    }
}

void solve(){
    if (sub1::check()){
        return sub1::solve();
    }

    if (sub5::check()){
        return sub5::solve();
    }

    if (sub3::check()){
        return sub3::solve();
    }
    return sub678::solve();
}

int main(){
    freopen("harvest.inp" , "r" , stdin);
    freopen("harvest.out" , "w" , stdout);
    faster;
    inp();
    solve();
    return 0;
}

#include<bits/stdc++.h>
using namespace std;
#define faster ios_base::sync_with_stdio(false) ; cin.tie(NULL)
#define fi first
#define se second

const int N = 2e5 + 7;
vector<pair<int , long long>> a[N];
int n , m;

struct edge{
    int u , v;
    long long w;
};

vector<edge> canh;

bool cmp(edge x , edge y){
    return x.w < y.w;
}

void inp(){
    cin >> n >> m;
    for (int i = 1 ; i <= m ; ++i){
        int u , v;
        long long w;
        cin >> u >> v >> w;
        a[u].push_back({v , w});
        a[v].push_back({u , w});
        edge e;
        e.u = u , e.v = v , e.w = w;
        canh.push_back(e);
    }
    sort(canh.begin() , canh.end() , cmp);
}

namespace sub2{
    bool check(){
        return m == n - 1;
    }

    void solve(){
        for (int u = 1 ; u <= n ; ++u){
            int id = 0;
            long long w = 0;
            for (auto &c : a[u]){
                if (c.se > w){
                    w = c.se;
                    id = c.fi;
                }
            }
            cout << id << " ";
        }
    }
}

namespace sub{
    int par[N];
    void make_set(){
        for (int i = 1 ; i <= n ; ++i) par[i] = i;
    }

    int find_par(int u){
        if (par[u] == u) return u;
        return par[u] = find_par(par[u]);
    }

    bool Union(int u , int v){
        u = find_par(u) , v = find_par(v);
        if (u == v) return 0;
        par[v] = u;
        return 1;
    }

    long long calc(int u , int v){
        make_set();
        par[v] = u;
        long long res = 0;
        int cnt = 1;
        for (int i = 0 ; i < canh.size() ; ++i){
            if (Union(canh[i].u , canh[i].v)){
                res += canh[i].w;
                ++cnt;
            }
            if (cnt == n - 1) break;
        }
        return res;
    }

    void solve(){
        for (int u = 1 ; u <= n ; ++u){
            int id = 0;
            long long w = 1e16;
            for (auto &c : a[u]){
                long long tmp = calc(u , c.fi);
                if (w > tmp){
                    w = tmp;
                    id = c.fi;
                }
                if (w == tmp){
                    id = min(id , c.fi);
                }
            }
            cout << id << " ";
        }
    }
}

void solve(){
    if (sub2::check()){
        return sub2::solve();
    }
    return sub::solve();
}

int main(){
    freopen("hades.inp" , "r" , stdin);
    freopen("hades.out" , "w" , stdout);
    faster;
    inp();
    solve();
    return 0;
}

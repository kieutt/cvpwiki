#include<bits/stdc++.h>
#define ll long long
using namespace std;
namespace solve1{
    ll sol(ll n, ll t1, ll t2, ll t3){
        ll ans = 0, d1 = 0, d2 = 0, d3 = 0, d12 = 0;
        ll r1 = t1,r2 = t2, r3 = t3;
        while(d3<n){
            ans++;
            r1--;
            if(r3 != t3) r3--;
            else{
                if(d1 == 0){
                    if(d12 != 0){
                        d12--;
                        d1++;
                    }
                }
                if(d2 == 0){
                    if(d12 != 0){
                        d12--;
                        d2++;
                    }
                }
                if(d1 != 0 && d2 != 0){
                    d1--;
                    d2--;
                    r3--;
                }
            }
            if(d1 == 0){
                if(d12 != 0){
                    d12--;
                    d1++;
                }
            }
            if(r2 != t2) r2--;
            else{
                if(d1 != 0){
                    d1--;
                    r2--;
                }
            }
            if(r1 == 0){
                r1 = t1;
                d1++;
            }
            if(r2 == 0){
                r2 = t2;
                d12++;
            }
            if(r3 == 0){
                r3 = t3;
                d3++;
            }
        }
        return ans;
    }
}
namespace solve2{
    ll sol(ll n, ll t1, ll t2, ll t3){
        ll ans = 0,d1 = 0,d2 = 0,d3 = 0,d12 = 0;
        while(n--){
            if(d1 == 0){
                if(d12 == 0){
                    ans+=t1;
                    d1++;
                }
                else{
                    d1++;
                    d12--;
                }
            }
            if(d2 == 0){
                if(d12 == 0){
                    ans+=t2;
                    d1--;
                    d2++;
                    ll s1 = t2/t1;
                    d1+=s1;
                }
                else{
                    d12--;
                    d2++;
                }
            }
            if(d1 == 0){
                if(d12 == 0){
                    ans+=t1;
                    d1++;
                }
                else{
                    d1++;
                    d12--;
                }
            }
            if(d3 == 0){
                ans+=t3;
                d1--;
                d2--;

                /// make12
                ll s = t3;
                if(t1 == 2 && t2 == 1){
                    ll r1 = t1;
                    for(int i = 1;i<=s;i++){
                        if(d1 != 0){
                            d1--;
                            d12++;
                            r1--;
                        }
                        else r1--;
                        if(r1 == 0){
                            r1 = t1;
                            d1++;
                        }
                    }
                }
                else{
                    if(d1 == 0){
                        s-=t1;
                        d1++;
                    }
                    d1+=s/t1;
                    d12+=s/t2;
                }
                ///end

            }
        }
        return ans;
    }
}
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    freopen("harvest.inp","r",stdin);
    freopen("harvest.out","w",stdout);
    ll n,t1,t2,t3;
    cin>>n>>t1>>t2>>t3;
    if(t3%t2 == 0 && t2%t1 == 0){
        cout<<solve2::sol(n,t1,t2,t3);
        return 0;
    }
    cout<<solve1::sol(n,t1,t2,t3);
    return 0;
}

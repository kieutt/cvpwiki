#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    freopen("shiftrev.inp","r",stdin);
    freopen("shiftrev.out","w",stdout);
    int n,m;
    string sss,t;
    cin>>n>>m>>sss>>t;
    /// check clen:
    string r1 = sss;
    string r2 = t;
    sort(r1.begin(),r1.end());
    sort(r2.begin(),r2.end());
    if(r1 != r2){
        cout<<"-1";
        return 0;
    }
    queue<pair<vector<int>,string>>qu;
    vector<int>v,vec;
    string ans = "";
    qu.push({v,sss});
    set<string>st;
    map<string,int>mp;
    st.insert(sss);
    while(!qu.empty()){
        string se = qu.front().second;
        vector<int>vv = qu.front().first;
        if(vv.size()>m) break;
        if(se == t){
            ans = se;
            v = qu.front().first;
            break;
        }
        qu.pop();
        for(int x = 1;x<se.size();x++){
            string ne_s = "";
            for(int j = se.size()-1;j>=se.size()-x;j--) ne_s+=se[j];
            for(int j = 0;j<se.size()-x;j++) ne_s+=se[j];
            if(st.find(ne_s) == st.end()){
                vec = vv;
                vec.push_back(x);
                qu.push({vec,ne_s});
                st.insert(ne_s);
            }
        }
    }
    if(ans == ""){
        cout<<"-1";
        return 0;
    }
    cout<<v.size()<<"\n";
    for(auto r : v) cout<<r<<" ";
    return 0;
}


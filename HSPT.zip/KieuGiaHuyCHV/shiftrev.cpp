#include <bits/stdc++.h>
using namespace std;
#define TASK "shiftrev"
#define double long double
#define FOR(i, a, b) for(int i = (a), _b = (b); i <= _b; ++i)
#define FORD(i, a, b) for(int i = (a), _b = (b); i >= _b; --i)
#define FORV(v, h) for(auto &v : h)
#define fi first
#define se second
#define vi vector<int>
#define vvi vector<vi>
#define ii pair<int, int>
#define vii vector<ii>
#define all(x) x.begin(), x.end()
#define reset(f, x) memset(f, x, sizeof(f))
#define TIME 1.0 * clock() / CLOCKS_PER_SEC
#define sz(x) (long long)x.size()
#define psi pair<string, int>

const int oo = 1e18;
const int MAXN = 2e3 + 5;

int n, m;
string s, t;

namespace subtask1{

    map <string, int> dist;
    map <string, bool> vis;
    map <string, psi> trace;
    string pre[MAXN], suf[MAXN];

    void bfs(){
        queue <string> qu;
        vis[s] = 1;
        dist[s] = 0;
        qu.push(s);
        while (sz(qu)){
            string x = qu.front();
            if (x == t || dist[x] == m) break;
            qu.pop();
            FOR(i, 1, n) pre[i] = pre[i - 1] + x[i];
            FORD(i, n, 1) suf[i] = suf[i + 1] + x[i];
            FOR(i, 1, n){
                string y = " " + suf[n - i + 1] + pre[n - i];
                if (!vis[y]){
                    trace[y] = psi(x, i);
                    vis[y] = 1;
                    dist[y] = dist[x] + 1;
                    qu.push(y);
                }
            }
        }
    }

    void SOLVE(){
        pre[0] = suf[n + 1] = "";
        bfs();
        if (vis[t] && dist[t] <= m){
            cout << dist[t] << '\n';
            vi res; res.clear();
            while (t != s){
                psi p = trace[t];
                res.push_back(p.se);
                t = p.fi;
            }
            reverse(all(res));
            FORV(r, res) cout << r << " ";
        } else cout << -1 << '\n';
    }

}

namespace greedy{

    int cs[26], ct[26];

    bool check(){
        FOR(i, 1, n) cs[s[i] - 'a']++;
        FOR(i, 1, n) ct[t[i] - 'a']++;
        FOR(i, 0, 25) if (cs[i] != ct[i]) return 0;
        return 1;
    }

}

main(){
    if (fopen(TASK".inp", "r")){
        freopen(TASK".inp", "r", stdin);
        freopen(TASK".out", "w", stdout);
    }
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    cin >> n >> m >> s >> t;
    s = " " + s;
    t = " " + t;
    if (greedy::check() == 0){
        cout << -1 << '\n';
        return 0;
    }
    if (n <= 8) return subtask1::SOLVE(), 0;
    return 0;
}

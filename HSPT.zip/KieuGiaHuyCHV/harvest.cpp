#include <bits/stdc++.h>
using namespace std;
#define TASK "harvest"
#define int long long
#define double long double
#define FOR(i, a, b) for(int i = (a), _b = (b); i <= _b; ++i)
#define FORD(i, a, b) for(int i = (a), _b = (b); i >= _b; --i)
#define FORV(v, h) for(auto &v : h)
#define fi first
#define se second
#define vi vector<int>
#define vvi vector<vi>
#define ii pair<int, int>
#define vii vector<ii>
#define all(x) x.begin(), x.end()
#define reset(f, x) memset(f, x, sizeof(f))
#define mid(l, r) (l + r) / 2
#define TIME 1.0 * clock() / CLOCKS_PER_SEC

const int oo = 4e18;
const int MAXN = 1e3 + 5;

int n, t1, t2, t3;

namespace subtask1{

    void SOLVE(){
        cout << t1 + t2 + t3 << '\n';
    }

}

namespace subtask2{

    void SOLVE(){
        cout << n * t3 + 2 << '\n';
    }

}

namespace subtask3{

    void SOLVE(){
        cout << n * (t2 + t3) + t1 << '\n';
    }

}

namespace subtask8{

    bool check(int mid){
        int k = min({(mid - t1 - t2) / t3, (mid - t1) / t2, mid / t1});
        return k >= n;
    }

    void SOLVE(){
        int l = 0, r = oo + 1;
        while (r - l > 1){
            int mid = mid(l, r);
            if (check(mid)) r = mid;
            else l = mid;
        }
        cout << r << '\n';
    }

}

namespace subtask7{


    void SOLVE(){
        int t = 0, s1 = 0, s2 = 0, s3 = 0, r1 = 0, r2 = 0, r3 = 0;
        while (s3 < n){
            if (s2 > 0 && r3 == t3){
                s3++;
                r3 = 0;
                s2--;
            }
            if (s2 > 0) r3++;
            if (s1 > 0 && r2 == t2){
                s2++;
                r2 = 0;
                s1--;
            }
            if (s1 > 0) r2++;
            r1++;
            if (r1 == t1){
                s1++;
                r1 = 0;
            }
            t++;
        }
        cout << t - 1 << '\n';
    }

}

main(){
    if (fopen(TASK".inp", "r")){
        freopen(TASK".inp", "r", stdin);
        freopen(TASK".out", "w", stdout);
    }
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    cin >> n >> t1 >> t2 >> t3;
    if (n == 1) return subtask1::SOLVE(), 0;
    if (t1 == 1 && t2 == 1 && t3 > 2) return subtask2::SOLVE(), 0;
    if (t1 == t2 && t2 > t3) return subtask3::SOLVE(), 0;
    if (max({t1, t2, t3}) <= 100 && n <= 100) return subtask7::SOLVE(), 0;
    return subtask8::SOLVE(), 0;
    return 0;
}

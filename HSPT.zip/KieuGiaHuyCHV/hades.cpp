#include <bits/stdc++.h>
using namespace std;
#define TASK "hades"
#define int long long
#define double long double
#define FOR(i, a, b) for(int i = (a), _b = (b); i <= _b; ++i)
#define FORD(i, a, b) for(int i = (a), _b = (b); i >= _b; --i)
#define FORV(v, h) for(auto &v : h)
#define fi first
#define se second
#define vi vector<int>
#define vvi vector<vi>
#define ii pair<int, int>
#define vii vector<ii>
#define all(x) x.begin(), x.end()
#define reset(f, x) memset(f, x, sizeof(f))
#define TIME 1.0 * clock() / CLOCKS_PER_SEC

const int oo = 1e18;
const int MAXN = 2e5 + 5;

int n, m;
vii G[MAXN];

struct edges{
    int u, v, c;
} adj[MAXN];

namespace subtask2{

    void SOLVE(){
        FOR(u, 1, n){
            int mx = 0, res = 0;
            FORV(g, G[u]){
                int v = g.fi, c = g.se;
                if (c > mx){
                    mx = c;
                    res = v;
                }
            }
            cout << res << ' ';
        }
    }

}

namespace subtask5{

    int cost[MAXN], cnt[MAXN], ans[MAXN], res[MAXN];

    void SOLVE(){
        FOR(u, 1, n) ans[u] = +oo;
        int sum = 0;
        FOR(i, 1, m) sum += adj[i].c;
        FOR(i, 1, m){
            int s = sum - adj[i].c;
            int u = adj[i].u;
            FORV(g, G[u]){
                int v = g.fi, c = g.se;
                if (v == adj[i].v) continue;
                cost[v] = c;
                cnt[v]++;
            }
            u = adj[i].v;
            FORV(g, G[u]){
                int v = g.fi, c = g.se;
                if (v == adj[i].u) continue;
                cnt[v]++;
                if (cnt[v] > 1) s -= max(cost[v], c);
            }
            u = adj[i].u;
            int v = adj[i].v;
            if (s < ans[u]){
                ans[u] = s;
                res[u] = v;
            } else if (s == ans[u]) res[u] = min(res[u], v);
            if (s < ans[v]){
                ans[v] = s;
                res[v] = u;
            } else if (s == ans[v]) res[v] = min(res[v], u);
            FORV(g, G[u]) cnt[g.fi] = cost[g.fi] = 0;
            FORV(g, G[v]) cnt[g.fi] = cost[g.fi] = 0;
        }
        FOR(u, 1, n) cout << res[u] << ' ';
    }

}

main(){
    if (fopen(TASK".inp", "r")){
        freopen(TASK".inp", "r", stdin);
        freopen(TASK".out", "w", stdout);
    }
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    cin >> n >> m;
    FOR(i, 1, m){
        int u, v, c;
        cin >> u >> v >> c;
        G[u].push_back(ii(v, c));
        G[v].push_back(ii(u, c));
        adj[i] = {u, v, c};
    }
    if (m == n - 1) return subtask2::SOLVE(), 0;
    return subtask5::SOLVE(), 0;
    return 0;
}

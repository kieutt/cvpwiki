#include <bits/stdc++.h>
using namespace std;
#define int long long
#define MASK(i) (1ll << (i))
#define pb push_back
#define BIT(mask, i) (mask & (1ll << (i)))
#define ONBIT(mask, i) (mask | (1ll << (i)))
#define cntbit(mask) __builtin_popcountll(mask)


const int oo   = 1e18;
const int MAXN = 4e5 + 15;

int N, M;

struct Edge {
    int v, w;
};

struct canh {
    int u, v, w;
};

struct cmp {
    bool operator() (canh a, canh b){
        return a.w < b.w;
    }
};

struct Dosu {
    int par[MAXN], sz[MAXN];

    void INIT(int u, int v) {
        for (int i = 1; i <= N + 1; i++) {
            if (i == u || i == v) continue;
            par[i] = i;
            sz[i]  = 1;
        }
    }

    int find_set(int u) {
        if (par[u] == u) return u;
        return par[u] = find_set(par[u]);
    }

    void union_set(int u, int v) {
        u = find_set(u);
        v = find_set(v);
        if (u == v) return;
        if (sz[u] < sz[v]) swap(u, v);
        par[v] = u;
        sz[u] += sz[v];
    }
} DSU;

vector<Edge> g[MAXN];
vector<canh> de;

namespace Subtaskct {
    void SOLVE() {
        for (int i = 1; i <= M; i++) {
            int u, v, w;
            cin >> u >> v >> w;
            g[u].pb({v, w});
            g[v].pb({u, w});
        }

        for (int u = 1; u <= N; u++) {
            int res = 0, ma = 0;
            for (auto E : g[u]) {
                int v = E.v;
                int w = E.w;
                if (w > ma) {
                    ma = w;
                    res = v;
                }
                else if (w == ma) res = min(res, v);
            }
            cout << res << ' ';
        }
    }
}

namespace Subtaskcay {
    void SOLVE() {
        for (int i = 1; i <= M; i++) {
            int u, v, w;
            cin >> u >> v >> w;
            g[u].pb({v, w});
            g[v].pb({u, w});
        }

        for (int u = 1; u <= N; u++) {
            int res = 0, ma = 0;
            for (auto E : g[u]) {
                int v = E.v;
                int w = E.w;
                if (w > ma) {
                    ma = w;
                    res = v;
                }
                else if (w == ma) res = min(res, v);
            }
            cout << res << ' ';
        }
    }
}

namespace Subtasktham {
    void SOLVE() {
        for (int i = 1; i <= M; i++) {
            int u, v, w;
            cin >> u >> v >> w;
            g[u].pb({v, w});
            g[v].pb({u, w});
            de.pb({u, v, w});
        }

        for (int u = 1; u <= N; u++) {
            int res = 0, ma = oo;
            for (auto E : g[u]) {
                int v = E.v;
                int MST = 0;
                DSU.INIT(u, v);
                vector<canh> Edg;
                for (auto c : de) {
                    int u1 = c.u;
                    int v1 = c.v;
                    int w1 = c.w;
                    if (u1 == u && v1 == v) continue;
                    if (u1 == v && v1 == u) continue;
                    if (u1 == u || u1 == v) u1 = N + 1;
                    if (v1 == u || v1 == v) v1 = N + 1;
                    Edg.pb({u1, v1, w1});
                }
                sort(Edg.begin(), Edg.end(), cmp());
                for (auto c : Edg) {
                    int u1 = c.u;
                    int v1 = c.v;
                    int w1 = c.w;
                    if (DSU.find_set(u1) == DSU.find_set(v1)) continue;
                    else {
                        MST += w1;
                        DSU.union_set(u1, v1);
                    }
                }
                if (MST < ma) {
                    ma = MST;
                    res = v;
                }
                else if (MST == ma) res = min(res, v);
                //cout << u << ' ' << v << ' ' << MST << '\n';
            }
            cout << res << ' ';
        }
    }
}

void PROCESS() {
    if (N == 2) {
        for (int i = 1; i <= M; i++) {
            int u, v, w;
            cin >> u >> v >> w;
        }
        cout << 2 << ' ' << 1;
        return;
    }
    if (N == M) {
        Subtaskct :: SOLVE();
        return;
    }

    if (M == N - 1) {
        Subtaskcay :: SOLVE();
        return;
    }

    Subtasktham :: SOLVE();
}


main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    freopen("shiftrev.inp", "r", stdin);
    freopen("shiftrev.out", "w", stdout);

    cin >> N >> M;
    string S, T;
    cin >> S >> T;
    cout << -1;

    //PROCESS();
}

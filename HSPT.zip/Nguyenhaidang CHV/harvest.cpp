#include <bits/stdc++.h>
using namespace std;
#define int long long
#define MASK(i) (1ll << (i))
#define pb push_back
#define BIT(mask, i) (mask & (1ll << (i)))
#define ONBIT(mask, i) (mask | (1ll << (i)))
#define cntbit(mask) __builtin_popcountll(mask)


const int oo   = 1e18;
const int MAXN = 1015;

int N, A, B, C;

main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    freopen("harvest.inp", "r", stdin);
    freopen("harvest.out", "w", stdout);

    cin >> N >> A >> B >> C;
    int a = N * A + B + C;
    int b = A + B * N + C;
    int c = A + B + C * N;
    cout << max({a, b, c});
}

#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("shiftrev.inp", "r", stdin);
    freopen("shiftrev.out", "w", stdout);
    string s,t;
    int n,m;
    cin >> n >> m;
    cin >> s >> t;
    cout << -1;
    return 0;
}

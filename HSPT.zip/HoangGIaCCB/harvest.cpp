#include <bits/stdc++.h>
using namespace std;
int o1 = 0 , o2 = 0, o3 = 0;
int t1,t2,t3 = 0;
int n;
int n1 = 1, n2 = 0, n3 = 0;
int nr = 0;
void bt()
{
    while( o1 >= t1)
    {
        n1 += o1 / t1;
        o1 -= (o1 / t1 ) * t1;
    }
    while(o2 >= t2 )
    {
        n2 ++;
        nr++;
        o2 -= t2 ;
    }
    while(n1 > 0 && n2 > 0 && o3 >= t3 )
    {
        o3-= t3;
        n1-- ;
        n2 --;
        n3++;
    }

}
void sl1(){
    int ans = t1;
    while(n3 < n)
    {

        while( n1 > 0 && n2 > 0 && n3 < n  )
        {
            o1 += t3;
            o2 += t3;
            ans += t3;
            n1--;
            n2 --;
            n3++;
            bt();
            if( n3 == n) break;
        }
        if( n3 == n)break;
        bt();
        if( n1 > 0 && nr < n )
        {
            n1--;
            n2++;
            o1  += t2;
            ans += t2;
            nr ++;
            if (n1  > 0 && n2 > 0) o3 += t2;
        }
        bt();
        if( n3 == n ) break;
        if(n1 == 0)
        {
            ans += t1;
            n1++;
            bt;
        }

    }
    cout << ans;
}


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    freopen("harvest.inp"," r", stdin);
    freopen("harvest.out"," w", stdout);
    cin >> n >> t1 >> t2 >> t3;
    sl1();
    return 0;
}

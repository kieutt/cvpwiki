/*
    Author : kmv___
    Road to tst
*/

#include<bits/stdc++.h>

using namespace std;

const int N = 2e3 + 5;

int n, m;
char s[N], t[N];
char a[N];
int ds[26], dt[26];

vector < int > act;

void push(int x){
    if (0 < x && x <= n){
        act.push_back(x);
        int idx = 0;
        for (int i = n; i >= n - x + 1; i --)
            a[++ idx] = s[i];
        for (int i = 1; i < n - x + 1; i ++)
            a[++ idx] = s[i];
        for (int i = 1; i <= n; i ++)
            s[i] = a[i];
    }
}

void dao(int len){
    if (len > n || len < 1)
        return;
    push(n);
    push(n - len);
}

void print(){
    if ((int) act.size() > m){
        cout << -1;
        return;
    }

    cout << act.size() << '\n';

    for (int i : act)
        cout << i << " ";
}

void sol(int i){
    for (int j = i; j <= n; j ++)
        if (s[j] == t[i]){
            dao(n - j + 1);
            push(1);
            return;
        }
}

void SOLVE(){
    cin >> n >> m;

    for (int i = 1; i <= n; i ++)
        cin >> s[i];
    for (int i = 1; i <= n; i ++)
        cin >> t[i];

    for (int i = 1; i <= n; i ++){
        ds[s[i] - 'a'] ++;
        dt[t[i] - 'a'] ++;
    }

    for (int i = 0; i < 26; i ++)
        if (ds[i] != dt[i]){
            cout << -1;
            return;
        }

    for (int i = 1; i <= n; i ++){
        sol(i);
    }

    push(n);

    print();
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);

    #define TASK "shiftrev"

    if (fopen(TASK".inp", "r")){
        freopen(TASK".inp","r",stdin);
        freopen(TASK".out","w",stdout);
    }

    int nTest = 1;

//    cin >> nTest;

    while (nTest --){
        SOLVE();
    }

    return 0;
}


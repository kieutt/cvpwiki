/*
    Author : kmv___
    Road to tst
*/

#include<bits/stdc++.h>

using namespace std;

int n, t1, t2, t3;

namespace SUB1{
    void SOLVE(){
        int b1 = 0, b2 = -1, b3 = -1;
        int d2 = 0, d3 = 0;

        int cnt = 0;

        for (int i = 1; i <= 1e8; i ++){
            if (b3 != -1 && (i - b3) == t3){
                cnt ++;
                d3 --;
                if (d3 == 0)
                    b3 = -1;
                else
                    b3 = i;
            }

            if (b2 != -1 && (i - b2) == t2){
                d2 --;
                if (d2 == 0)
                    b2 = -1;
                else
                    b2 = i;
                d3 ++;
                if (b3 == -1)
                    b3 = i;
            }

            if (i - b1 == t1){
                d2 ++;
                if (b2 == -1)
                    b2 = i;
                b1 = i;
            }

            if (cnt == n){
                cout << i;
                return;
            }
        }
    }
}

void SOLVE(){
    cin >> n >> t1 >> t2 >> t3;

    if (t2 <= 2 && t3 <= 2){
        SUB1 :: SOLVE();
        return;
    }

    if (t1 == 2 && t2 == 1){
        cout << 3 + n * t3;
        return;
    }

    if (t1 == 2 && t3 == 1){
        cout << n * t2 + 3;
        return;
    }

    if (t2 <= t3){
        cout << t3 * n + t1 + t2;
        return;
    }

    if (t2 > t3){
        cout << t1 + t2 * n + t3;
        return;
    }
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);

    #define TASK "harvest"

    if (fopen(TASK".inp", "r")){
        freopen(TASK".inp","r",stdin);
        freopen(TASK".out","w",stdout);
    }

    int nTest = 1;

//    cin >> nTest;

    while (nTest --){
        SOLVE();
    }

    return 0;
}


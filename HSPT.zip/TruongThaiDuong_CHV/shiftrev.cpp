# include <bits/stdc++.h>
using namespace std;

const long long N = 2e3+3;

long long n, m;
string a, b;

int main()
{
    if(fopen("shiftrev.inp", "r")) {
        freopen("shiftrev.inp", "r", stdin);
        freopen("shiftrev.out", "w", stdout);
    }

    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);

    cin>>n>>m;
    cin>>a;
    cin>>b;

    cout<<-1;

    return 0;
}

# include <bits/stdc++.h>

# define pa pair<long long, long long>
# define fi first
# define se second

using namespace std;

const long long N = 2e5+5;

struct day {
    long long u, v, w;
};

bool cmp(day x, day y) {
    return x.w < y.w;
}

long long n, m;

day a[N];

vector<long long> way[N];
vector<pa> rood[N];

long long par[N], sz[N];

void build_par() {
    for(long long i = 1; i <= n; i++) {
        par[i] = i;
        sz[i] = 1;
    }
}

long long find_par(long long u) {
    if(par[u] == u) {
        return par[u];
    }

    par[u] = find_par(par[u]);

    return par[u];
}

bool kethop(long long u, long long v) {
    u = find_par(u), v = find_par(v);

    if(u == v) {
        return 0;
    }

    if(sz[u] < sz[v]) {
        swap(u, v);
    }

    par[v] = u, sz[u] += sz[v];
    return 1;
}

long long Min = 0;

void build_tree() {
    for(long long i = 1; i <= m; i++) {
        way[a[i].u].push_back(a[i].v);
        way[a[i].v].push_back(a[i].u);
        if(kethop(a[i].u, a[i].v)) {
            Min += a[i].w;
            rood[a[i].u].push_back({a[i].v, a[i].w});
            rood[a[i].v].push_back({a[i].u, a[i].w});
        }
    }
}

long long ha[N];
pa lca[N][20];

void build_ha(long long u, long long goc, long long w) {
    ha[u] = ha[goc] + 1;
    lca[u][0].fi = goc, lca[u][0].se = w;

    for(pa v : rood[u]) {
        if(v.fi == goc) {
            continue;
        }
        build_ha(v.fi, u, v.se);
    }
}

void build_lca() {
    for(long long j = 1; j < 20; j++) {
        for(long long i = 1; i <= n; i++) {
            lca[i][j].fi = lca[lca[i][j - 1].fi][j - 1].fi;
            lca[i][j].se = max(lca[i][j - 1].se, lca[lca[i][j - 1].fi][j - 1].se);
        }
    }
}

long long get_Max(long long u, long long v) {
    long long ans = 0;

    if(ha[u] < ha[v]) {
        swap(u, v);
    }

    long long x = ha[u] - ha[v];

    for(long long i = 19; i >= 0; i--) {
        if((x >> i) & 1) {
            ans = max(ans, lca[u][i].se);
            u = lca[u][i].fi;
        }
    }

    if(u == v) {
        return ans;
    }

    for(long long i = 19; i >= 0; i--) {
        if(lca[u][i].fi != lca[v][i].fi) {
            ans = max(ans, max(lca[u][i].se, lca[v][i].se));
            u = lca[u][i].fi, v = lca[v][i].fi;
        }
    }

    ans = max(ans, max(lca[u][0].se, lca[v][0].se));

    return ans;
}

int main()
{
    if(fopen("hades.inp", "r")) {
        freopen("hades.inp", "r", stdin);
        freopen("hades.out", "w", stdout);
    }

    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);

    cin>>n>>m;
    for(long long i = 1; i <= m; i++) {
        cin>>a[i].u>>a[i].v>>a[i].w;
    }

    sort(a + 1, a + 1 + m, cmp);

    build_par();
    build_tree();
    build_ha(1, 0, 0);
    build_lca();

    for(long long i = 1; i <= n; i++) {
        sort(way[i].begin(), way[i].end());

        long long Max = 0, vt = 0;

        for(long long v : way[i]) {
            long long x = get_Max(i, v);
            if(x > Max) {
                Max = x;
                vt = v;
            }
        }

        cout<<vt<<" ";
    }

    return 0;
}

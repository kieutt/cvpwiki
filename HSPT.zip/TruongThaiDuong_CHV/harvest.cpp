# include <bits/stdc++.h>
using namespace std;

const int N = 1e3+3;
const int MAXT = 3e8+8;

int n, a1, a2, a3;

priority_queue<int, vector<int>, greater<>> q;

int main()
{
    if(fopen("harvest.inp", "r")) {
        freopen("harvest.inp", "r", stdin);
        freopen("harvest.out", "w", stdout);
    }

    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);

    cin>>n;
    cin>>a1>>a2>>a3;

    int s = 0, s1 = 0, s2 = 0;
    int kt2 = 0, kt3 = 0;

    q.push(a1);

    while(n > 0) {
        if(q.top() <= s) {
            q.pop();
            continue;
        }

        s = q.top();
        q.pop();

        if(s % a1 == 0) {
            s1++;
            if(s1 <= n * 2) {
                q.push(s + a1);
            }
        }
        if(s == kt2) {
            s2++;
        }
        if(s == kt3) {
            n--;
        }

        if(kt3 <= s) {
            kt3 = (s1 > 0 && s2 > 0);
            s1 -= kt3, s2 -= kt3;
            kt3 *= (s + a3);
            if(kt3) {
                q.push(kt3);
            }
        }
        if(kt2 <= s) {
            kt2 = (s1 > 0);
            s1 -= kt2;
            kt2 *= (s + a2);
            if(kt2 && s2 <= n) {
                q.push(kt2);
            }
        }
    }

    cout<<s;

    return 0;
}

#include<bits/stdc++.h>
#define I first
#define II second
#define ii pair<int, int>
#define lg2(n) 31 - __builtin_clz(n)
#define ll long long
#define int ll
#define it array<int, 3>
using namespace std;
const long long P = 1e9 + 7;
const int N = 2e5 + 10;
const long long INF = 1e18;
void input()
{
#define TASKNAME "hades"
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    if (fopen(TASKNAME".inp", "r"))
    {
        freopen(TASKNAME".inp", "r", stdin);
        freopen(TASKNAME".out", "w", stdout);
    }
}
int n, m;
bool cmp (it a, it b)
{
    return (a[2] < b[2]);
}

vector<it> ed;
namespace sub1
{
ii ans[N];
bool checksub1()
{
    return (m <= 5000);
}
struct DSU
{
    int n;
    vector<int> parent, sz;
    DSU(int _n)
    {
        parent.resize(_n + 1);
        n = _n;
        sz.resize(n + 1);
    }
    void make_set(int n)
    {
        for (int i=1; i<=n; i++)
        {
            parent[i] = i;
            sz[i] = 1;
        }
    }
    int find_set(int u)
    {
        return (u == parent[u] ? u : parent[u] = find_set(parent[u]));
    }
    void joint_set(int u, int v)
    {
        u = find_set(u);
        v = find_set(v);
        if (u != v)
        {
            if (sz[u] < sz[v]) swap(u, v);
            parent[v] = u;
            sz[u] += sz[v];
        }
    }
} f(N);
int32_t main ()
{
    for (int i=1; i<=n; i++)
    {
        ans[i] = {INF, INF};
    }
    for (int x = 0; x<ed.size(); x++)
    {
        int u = ed[x][0];
        int v = ed[x][1];
        int w = ed[x][2];
        f.make_set(n);
        f.joint_set(u, v);
        int res = 0;
        for (int t=0; t<ed.size(); t++)
        {
            int U = ed[t][0];
            int V = ed[t][1];
            int W = ed[t][2];
            if (f.find_set(U) != f.find_set(V))
            {
                f.joint_set(U, V);
                res += W;
            }
        }
        ans[u] = min(ans[u], {res, v});
        ans[v] = min(ans[v], {res, u});
    }
    for (int i=1; i<=n; i++)
    {
        cout << ans[i].II << ' ';
    }
    cout << endl;
    return 0;
}
}
namespace sub2
{
bool checksub2()
{
    return (m == n - 1);
}
ii ans[200010];
int32_t main()
{
    for (int i=1; i<=n; i++)
    {
        ans[i] = {INF, INF};
    }
    int sum = 0;
    for (int i=0; i<ed.size(); i++)
    {
        sum += ed[i][2];
    }
    for (int x=0; x<ed.size(); x++)
    {
        int u = ed[x][0];
        int v = ed[x][1];
        int w = ed[x][2];
        ans[u] = min(ans[u], {sum - w, v});
        ans[v] = min(ans[v], {sum - w, u});
    }
    for (int i=1; i<=n; i++) cout << ans[i].II << ' ';
    return 0;
}
}
namespace sub3
{
bool checksub3()
{
    return (m == n) ;// co duy nhat 1 chu trinh don
}
struct DSU
{
    int n;
    vector<int> parent, sz;
    DSU(int _n)
    {
        parent.resize(_n + 1);
        n = _n;
        sz.resize(n + 1);
    }
    void make_set(int n)
    {
        for (int i=1; i<=n; i++)
        {
            parent[i] = i;
            sz[i] = 1;
        }
    }
    int find_set(int u)
    {
        return (u == parent[u] ? u : parent[u] = find_set(parent[u]));
    }
    void joint_set(int u, int v)
    {
        u = find_set(u);
        v = find_set(v);
        if (u != v)
        {
            if (sz[u] < sz[v]) swap(u, v);
            parent[v] = u;
            sz[u] += sz[v];
        }
    }
} f(N);
ii ans[N];
bool vis[N];
bool mark[N];
vector<it> g[N];
ii par[N];
int h[N];
void dfs(int u, int p)
{
    for (auto [v, w, i] : g[u])
    {
        if (v == p) continue;
        par[v] = {u, i};
        h[u] = h[v] + 1;
        dfs(v, u);
    }
}
void jump(int u, int v)
{
    if (h[v] > h[u]) swap(u, v);
    while (h[u] > h[v])
    {
        mark[par[u].II] = 1;
        u = par[u].I;
    }
    while (par[u].I != par[v].I)
    {
        mark[par[u].II] = 1;
        mark[par[v].II] = 1;
        u = par[u].I;
        v = par[v].I;
    }
}
int32_t main ()
{
    for (int i=1; i<=n; i++)
    {
        ans[i] = {INF, INF};
    }
    f.make_set(n);
    int sum = 0;
    int tot = 0;
    for (int i=0; i<ed.size(); i++)
    {
        auto [u, v, w] = ed[i];
        tot += w;
        if (f.find_set(u) != f.find_set(v))
        {
            f.joint_set(u, v);
            sum += w;
            vis[i] = 1;
        }
    }
    for (int i=0; i < ed.size(); i++)
    {
        if (vis[i])
        {
            auto [u, v, w] = ed[i];
//            cout << u << ' ' << v << ' ' << w << endl;
            g[u].push_back({v, w, i});
            g[v].push_back({u, w, i});
        }
    }
    h[1] = 1;
    dfs(1, 0);
    int p = -1;
    int U = -1, V = -1;
    for (int i=0; i<ed.size(); i++)
    {
        if (vis[i] == 0)
        {
            U = ed[i][0];
            V = ed[i][1];
            p = i;
        }
    }
    mark[p] = 1;
    jump(U, V);
    vector<it> ed2;
    for (int i=0; i<ed.size(); i++)
    {
        auto [u, v, w] = ed[i];
        if (mark[i] == 0)
        {
            ans[u] = min(ans[u], {sum - w, v});
            ans[v] = min(ans[v], {sum - w, u});
        }
        else
        {
//            cout << u << ' ' << v << endl;
            ed2.push_back({u, v, w});
        }
    }
    sort(ed2.begin(), ed2.end(), cmp);
//    cout << ed2.size() << endl;
    for (int i=0; i<ed.size(); i++)
    {
        auto [u, v, w] = ed[i];
        if (mark[i])
        {
            if (w == ed2.back()[2])
            {
                ans[u] = min(ans[u], {tot - w - ed2[ed2.size() - 2][2], v});
                ans[v] = min(ans[u], {tot - w - ed2[ed2.size() - 2][2], u});
            }
            else {
//                cout << u << ' ' << v << endl;
//                ans[u] = min(ans[u], {tot - w, v});
//                ans[v] = min(ans[v], {tot - w, u});
            }
        }
    }
    for (int i=1; i<=n; i++) cout << ans[i].II << ' ';
    return 0;
}
}
int32_t main ()
{
    input();
    cin >> n >> m;
    for (int i=1; i<=m; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;
        ed.push_back({u, v, w});
    }
    sort(ed.begin(), ed.end(), cmp);
    if(sub1::checksub1())
    {
        sub1::main();
        return 0;
    }
    if (sub2::checksub2())
    {
        sub2::main();
        return 0;
    }
    sub3::main();
    return 0;
}

#include<bits/stdc++.h>
#define I first
#define II second
#define ii pair<int, int>
#define lg2(n) 31 - __builtin_clz(n)
#define ll long long
#define int ll
using namespace std;
const long long P = 1e9 + 7;
const int N = 1e5 + 10;
const long long INF = 1e18;
void input() {
    #define TASKNAME "harvest"
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    if (fopen(TASKNAME".inp", "r")) {
        freopen(TASKNAME".inp", "r", stdin);
        freopen(TASKNAME".out", "w", stdout);
    }
}
int n;
int t1, t2, t3;
namespace sub1 {
    bool checksub1() {
        return (n == 1);
    }
    int32_t main() {
        int res1 = t1;
        res1 += t2;
        res1 += t3;
        cout << res1;
        return 0;
    }
}
namespace sub2 {
    bool checksub2 () {
        return (t1 == t2 && t1 == 1);
    }
    int32_t main () {
        if (t3 != 1) {
            cout << t3 * n + 2;
        }
        else if (t3 == 1) {
            cout << 2 * n + 1;
        }
        return 0;
    }
}
namespace sub3 {
    bool checksub3() {
        return (t1 == 1);
    }
    int32_t main () {
        if (t2 >= t3) {
            int res = 1 + n * t2;
            res += t3;
            cout << res;
        }
        else {
            int res = 1 + t2 + t3 * n;
            cout << res;
        }
        return 0;
    }
}
namespace sub4 {
    bool checksub4() {
        return (t1 == t2 && t1 == 2);
    }
    int32_t main () {
        if (t2 >= t3) {
            cout << 4 * n + t3;
        }
        else {
            int res = t1 + t2;
            res += t3 * n;
            cout << res;
        }
        return 0;
    }
}
namespace sub5 {
    bool checksub5() {
        return (t1 == 2 && t2 == 1);
    }
    int32_t main () {
        if (t2 == t3) {
            cout << 4 * n + t3;
        }
        else {
            cout << max(4 * n + t3, 2 * 2 + t3 * n);
        }
        return 0;
    }
}
int32_t main () {
    input();
    cin >> n;
    cin >> t1 >> t2 >> t3;
    if (sub1::checksub1()) {
        sub1::main();
        return 0;
    }
    if (sub2::checksub2()) {
        sub2::main();
        return 0;
    }
    if(sub3::checksub3()) {
        sub3::main();
        return 0;
    }
    if (sub4::checksub4()) {
        sub4::main();
        return 0;
    }
    if (sub5::checksub5()) {
        sub5::main();
        return 0;
    }
    return 0;
}


#include<bits/stdc++.h>
#define I first
#define II second
#define ii pair<int, int>
#define lg2(n) 31 - __builtin_clz(n)
#define ll long long
#define int ll
#define it array<int, 3>
using namespace std;
const long long P = 1e9 + 7;
const int N = 2e5 + 10;
const long long INF = 1e18;
void input()
{
#define TASKNAME "shiftrev"
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    if (fopen(TASKNAME".inp", "r"))
    {
        freopen(TASKNAME".inp", "r", stdin);
        freopen(TASKNAME".out", "w", stdout);
    }
}
int32_t main ()
{
    input();
    cout << -1;
    return 0;
}

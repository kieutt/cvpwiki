#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define maxn 1000006
#define MOD 1000000007
#define oo 1000000000000000000
#define base 9997
#define pd pair<ll, ll>
#define tp tuple<ll, ll, ll>
#define bitmask(mask, i) ((mask >> i) & 1)
#define __KezzyBlue__ int main()
#define name "harvest"
ll n, t1, t2, t3;
namespace sub1{
    void solve()
    {
       ll tmp = t1 + t2 + t3;
       if(t1 > t2)
            tmp += t1 - t2;
       cout << tmp;
    }
}
namespace sub2{
    void solve()
    {
        cout << n * t3 + 2;
    }
}
namespace sub3{
    void solve()
    {
        if(t2 <= t3)
            cout << n * t3 + 1 + t2;
        else
            cout << 1 + t2 + (n - 1) * t2 + t3;
    }
}
namespace sub4{
    void solve()
    {
        if(t3 > t1 + t2)
            cout << n * t3 + t1 * 2;
        else
            cout << t1 * 2 * n + t3;
    }
}
namespace hup{
    bool kt(ll x)
    {
        ll dem = 0;
        if(x / t1 >= n) dem++;
        if(t2 >= t1){
            if((x - t1) / t2 >= n) dem++;
        }
        else
        {
            if((x - t2) / t1 >= n) dem++;
        }
        if(t3 >= t1 + t2)
        {
            if((x - t1 - t2) / t3 >= n)
                dem++;
        }
        else
        {
            if(t1 > t2)
            {
                if((x - t2 - t3)/ t1 >= n)
                    dem++;
            }
            else
                if((x - t1 - t3) / t2 >= n)
                    dem++;
        }
        return dem == 3;
    }
    void solve()
    {
        ll d = 1, c = oo, ans = 0;
        while(d <= c)
        {
            ll g = d + c >> 1;
            if(kt(g))
            {
                ans = g;
                c = g - 1;
            }
            else
                d = g + 1;
        }
        cout << ans;
    }
}
void solve()
{
    if(n == 1) sub1::solve();
    else
    if(t1 == t2 && t2 == 1 && t3 > 2)
        sub2::solve();
    else
    if(t1 == 1)
        sub3::solve();
    else
    if(t1 == t2)
        sub4::solve();
    else
        hup::solve();
}
__KezzyBlue__
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    freopen(name".inp", "r", stdin);
    freopen(name".out", "w", stdout);
    cin >> n >> t1 >> t2 >> t3;
    solve();
}

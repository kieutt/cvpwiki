#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define maxn 1000006
#define MOD 1000000007
#define base 9997
#define pd pair<ll, ll>
#define tp tuple<ll, ll, ll>
#define bitmask(mask, i) ((mask >> i) & 1)
#define __KezzyBlue__ int main()
#define name "shiftrev"
ll n, m;
string s, t;
void solve()
{
    cout << -1;
}
__KezzyBlue__
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    freopen(name".inp", "r", stdin);
    freopen(name".out", "w", stdout);
    cin >> n >> m;
    cin >> s >> t;
    solve();
}

#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define maxn 1000006
#define MOD 1000000007
#define base 9997
#define pd pair<ll, ll>
#define tp tuple<ll, ll, ll>
#define bitmask(mask, i) ((mask >> i) & 1)
#define __KezzyBlue__ int main()
#define name "hades"
ll n, m;
vector<pd> a[maxn];
struct dt{
    ll u, v, w;
}tmp[maxn];
bool cmp(dt a, dt b){
    return a.w < b.w;
}
namespace sub1{
    ll par[maxn], f[maxn];
    ll find(ll u)
    {
        return (u == par[u] ? u : par[u] = find(par[u]));
    }
    bool unite(ll u, ll v)
    {
        u = find(u);
        v = find(v);
        if(u == v) return false;
        par[v] = u;
        return true;
    }
    ll co(ll u, ll v)
    {
        ll ans = 0;
        for(ll i = 1; i <= n; i++)
        {
            f[i] = i;
            par[i] = i;
        }
        f[v] = u;
        vector<tp> d;
        for(ll i = 1; i <= m; i++)
        {
            auto [x, y, w] = tmp[i];
            if(f[x] != f[y])
            d.push_back({w, f[x], f[y]});
        }
        for(auto &[w, x, y] : d)
        {
            if(unite(x, y))
                ans += w;
        }
        return ans;
    }
    void solve()
    {
        for(ll u = 1; u <= n; u++)
        {
            ll id = 1e18, mins = 1e18;
            for(auto &[v, w] : a[u])
            {
                ll x = co(u, v);
                if(mins > x)
                {
                    mins = x;
                    id = v;
                }
                else
                    if(mins == x)
                    id = min(id, v);
            }
            cout << id << " ";
        }
    }
}
namespace sub2{
    ll maxs[maxn], f[maxn];
    void solve()
    {

        for(ll i = 1; i <= m; i++)
        {
            auto &[u, v, w] = tmp[i];
            if(maxs[v] < w)
            {
                maxs[v] = w;
                f[v] = u;
            }
            else
                if(maxs[v] == w)
                    f[v] = min(f[v], u);
            if(maxs[u] < w)
            {
                maxs[u] = w;
                f[u] = v;
            }
            else
                if(maxs[u] == w)
                f[u] = min(f[u], v);
        }
        for(ll i = 1; i <= n; i++)
            cout << f[i] << " ";
    }
}
namespace sub3{
    ll low[maxn], num[maxn], cnt, scc = 0, f[maxn], maxs[maxn], ans[maxn];
    void dfs(ll u, ll par = -1)
    {
        low[u] = num[u] = ++cnt;
        for(auto &[v, w] : a[u])
            if(v != par)
            {
                if(num[v])
                {
                    low[u] = min(low[u], num[v]);
                }
                else
                {
                    dfs(v, u);
                    low[u] = min(low[u], low[v]);
                }
            }
    }
    void solve()
    {
        dfs(1);
        for(ll i = 1; i <= n; i++)
        {
            f[low[i]]++;
        }
        for(ll i = 1; i <= n; i++)
        {
            if(f[low[i]] > 2)
            {
                scc = low[i];
            }
        }
        vector<ll> cur;
        for(ll i = 1; i <= m; i++)
        {
            auto [u, v, w] = tmp[i];
            if(low[u] == scc && low[v] == scc)
                cur.push_back(w);
        }
        sort(cur.begin(), cur.end(), greater<ll>());
        for(ll u = 1; u <= n; u++)
        {
            for(auto &[v, w] : a[u])
            {
                ll sum = w;
                if(low[u] == scc && low[v] == scc)
                {
                    if(w == cur[0])
                        sum += cur[1];
                    else
                        sum += cur[0];
                }
                if(maxs[u] < sum){
                    maxs[u] = sum;
                    ans[u] = v;
                }
                else
                if(maxs[u] == sum)
                    ans[u] = min(ans[u], v);
            }
        }
        for(ll i = 1; i <= n; i++)
            cout << ans[i] << " ";
    }
}
namespace sub{
    ll par[maxn], maxs[maxn], ans[maxn];
    ll find(ll u)
    {
        return (u == par[u] ? u : par[u] = find(par[u]));
    }
    bool unite(ll u, ll v)
    {
        u = find(u);
        v = find(v);
        if(u == v) return false;
        par[v] = u;
        return true;
    }
    void solve()
    {
        sort(tmp + 1, tmp + m + 1, cmp);
        for(ll i = 1; i <= n; i++) par[i] = i;
        for(ll i = 1; i <= m; i++)
        {
            auto [u, v, w] = tmp[i];
            if(unite(u, v))
            {
                if(maxs[v] < w)
                {
                    maxs[v] = w;
                    ans[v] = u;
                }
                else
                    ans[v] = min(ans[v], u);
                if(maxs[u] < w)
                {
                    maxs[u] = w;
                    ans[u] = v;
                }
                else
                    ans[u] = min(ans[u], v);
            }
        }
        for(ll i = 1; i <= n; i++) cout << ans[i] << " ";
    }
}
void solve()
{
    if(m <= 5000)
        sub1::solve();
    else
    if(m == n - 1)
        sub2::solve();
    else
    if(n == m)
        sub3::solve();
    else
        sub::solve();
}
__KezzyBlue__
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    freopen(name".inp", "r", stdin);
    freopen(name".out", "w", stdout);
    cin >> n >> m;
    for(ll i = 1; i <= m; i++)
    {
        ll u, v, w;
        cin >> u >> v >> w;
        a[u].push_back({v, w});
        a[v].push_back({u, w});
        tmp[i] = {u, v, w};
    }
    solve();

}

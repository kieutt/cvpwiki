#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define all(v) v.begin(), v.end()
#define sz(x) (long long)(x.size())
#define fi first
#define se second
using namespace std;
const ll N = 2e5 + 9;
ll n, m, i, pa[N], sz[N], ans = 0, res[N], pos[N];
struct edge
{
    ll u, v, w;
};
vector<edge>box;

ll find_(ll x)
{
    return pa[x] == x ? x : pa[x] = find_(pa[x]);
}
void union_set(int vt)
{
    ll x = box[vt].u, y = box[vt].v, k = box[vt].w;
    x = find_(x);
    y = find_(y);
    if(x == y) return;
    ans += k;

    if(sz[x] < sz[y]) swap(x, y);
    sz[x] += sz[y];
    pa[y] = x;
}

ll mst(ll id)
{
    ans = 0;
    for(int j = 1; j <= n; j ++)
    {
        pa[j] = j;
        sz[j] = 1;
    }

    if(id != -1)
    {
        union_set(id);
        ans -= box[id].w;
    }
    for(int w = 0; w < sz(box); w ++)
        union_set(w);

    return ans;
}

namespace sub1
{
void main()
{
    for(i = 1; i <= n; i ++) res[i] = 1e18;

    for(int i = 0; i < sz(box); i ++)
    {
        ll kq = 1e18;

        kq = mst(i);

        ll x = box[i].u, y = box[i].v;
        if(res[x] > kq)
        {
            res[x] = kq;
            pos[x] = y;
        }
        else if(res[x] == kq && pos[x] > y) pos[x] = y;

        if(res[y] > kq)
        {
            res[y] = kq;
            pos[y] = x;
        }
        else if(res[y] == kq && pos[y] > x) pos[y] = x;
    }

    for(i = 1; i <= n; i ++)
        cout << pos[i] << " ";
}
}
namespace sub2{
void main(){
    for(i = 1; i <= n; i ++) res[i] = 0;

     for(int i = 0; i < sz(box); i ++)
    {
        ll kq = box[i].w;

        ll x = box[i].u, y = box[i].v;
        if(res[x] < kq)
        {
            res[x] = kq;
            pos[x] = y;
        }
        else if(res[x] == kq && pos[x] > y) pos[x] = y;

        if(res[y] < kq)
        {
            res[y] = kq;
            pos[y] = x;
        }
        else if(res[y] == kq && pos[y] > x) pos[y] = x;
    }

    for(i = 1; i <= n; i ++)
        cout << pos[i] << " ";
}
}
int main()
{
#define TN "hades"
    if(fopen(TN ".inp", "r"))
    {
        freopen(TN ".inp", "r", stdin);
        freopen(TN ".out", "w", stdout);
    }
    cin.tie(0)->sync_with_stdio(0);

    cin >> n >> m;
    for(i = 1; i <= m; i ++)
    {
        ll x, y, z;
        cin >> x >> y >> z;
        box.pb({x, y, z});
    }

    sort(all(box), [](edge a, edge b)
    {
        return a.w < b.w;
    });

    if(m <= 5000)
    {
        sub1::main();
        return 0;
    }

    if(m == n - 1){
        sub2::main();
        return 0;
    }


    sub1::main();
    return 0;
}
/*
3 3
1 2 1
2 3 2
1 3 3

10 9
1 2 2
1 3 5
1 4 7
2 8 4
3 5 6
3 6 3
4 7 8
8 9 5
7 10 3
*/

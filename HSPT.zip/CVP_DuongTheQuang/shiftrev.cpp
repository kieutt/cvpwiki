#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define all(v) v.begin(), v.end()
#define sz(x) (long long)(x.size())
#define fi first
#define se second
using namespace std;
const ll N = 1e4 + 9;
ll n, i, m, cnt1[300], cnt2[300];
string s, t;
vector<int>vec;

int main()
{
#define TN "shiftrev"
    if(fopen(TN ".inp", "r"))
    {
        freopen(TN ".inp", "r", stdin);
        freopen(TN ".out", "w", stdout);
    }
    cin.tie(0)->sync_with_stdio(0);
    cin >> n >> m;
    cin >> s >> t;

    for(i = 0; i < sz(s); i ++)
    {
        int x = (int)(s[i]);
        cnt1[x] ++;
    }

    for(i = 0; i < sz(t); i ++)
    {
        int x = (int)(t[i]);
        cnt2[x] ++;
    }

    for(i = 0; i < sz(t); i ++)
    {
        int x = (int)(t[i]);
        if(cnt1[x] != cnt2[x])
        {
            cout << -1;
            return 0;
        }
    }
    while(true)
    {
        int vt = -1, cnt = 0;
        for(int w = 0; w < sz(s); w ++)
        {
            if(s[w] == t[w])
            {
                cnt ++;
                continue;
            }

            vt = w;
            break;
        }
        if(vt == -1) break;

        int id = 0;
        for(int w = vt; w < sz(s); w ++)
        {
            if(s[w] == t[vt])
            {
                id = w;
                break;
            }
        }


        string p = "", q = "";

        if(sz(s) - id != 0)
            vec.pb(sz(s) - id);

        for(int w = 0; w < id; w ++) p += s[w];
        for(int w = id; w < sz(s); w ++) q += s[w];
        reverse(all(q));

        ll c = sz(p);

        string xau = q + p;

        s = xau;
        string t = q;
        t.pop_back();
        string res = "";
        for(int w = sz(t); w < sz(xau); w ++)res += xau[w];
        reverse(all(res));
        xau = res + t;

        if(sz(res))
            vec.pb(sz(res));
        string ans = "";
        for(int w = 0; w < sz(xau) - 1 - sz(t) + 1; w ++) ans += xau[w];
        res = "";
        for(int w = sz(xau) - 1 - sz(t) + 1; w < sz(xau); w ++) res += xau[w];

        if(sz(res))
            vec.pb(sz(res));
        reverse(all(res));

        xau = res + ans;
        vec.pb(1);
        char d = xau.back();
        xau.pop_back();
        xau = d + xau;
        s = xau;
        res = "", ans = "";
        for(int w = 0; w < sz(xau) - 1 - cnt + 1; w ++) ans += xau[w];
        for(int w = sz(xau) - 1 - cnt + 1; w < sz(xau); w ++) res += xau[w];
        reverse(all(res));
        if(cnt)
            vec.pb(cnt);
        s = res + ans;
    }
    // cout << s;
    if(sz(vec) > m)
    {
        cout << -1;
        return 0;
    }

    cout << sz(vec) << "\n";
    for(auto x : vec) cout << x << "\n";
    return 0;
}
/*
6 10000
xyxzyy
yxyzyx
*/

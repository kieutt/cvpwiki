#include <bits/stdc++.h>

#define ll long long
#define fi first
#define se second
#define len(s) (ll) s.size()
#define LS(x) (1LL << x)
#define Lg(x) (x > 0 ? 31 - __builtin_clz(x) : 0)

const ll I = 2e5 + 9;
const ll Z = 1e9 + 7;
const ll inf = 1e15;

using namespace std;

template <typename U, typename V>
bool maxz(U &a, V b) { return a < b ? a = b, 1 : 0; }
template <typename U, typename V>
bool minz(U &a, V b) { return a > b ? a = b, 1 : 0; }

int n, m;
ll sum = 0;
vector<pair<int, int>> adj[I];

namespace sub2
{
    void solve()
    {
        for (int i = 1; i <= n; i++)
        {
            ll best = sum, ans = n + 1;
            for (auto z : adj[i])
            {
                ll x = sum - z.se;
                if(x < best)
                {
                    x = best;
                    ans = z.fi;
                }
                else 
                if(x == best)
                minz(ans, z.fi);
            }
            cout << ans << " ";
        }
    }
}

int main()
{
#define TN "hades"
    if (fopen(TN ".inp", "r"))
    {
        freopen(TN ".inp", "r", stdin);
        freopen(TN ".out", "w", stdout);
    }
    cin.tie(0)->sync_with_stdio(0);
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back({v, w});
        adj[v].push_back({u, w});
        sum += w;
    }
    if (m == n - 1)
        sub2::solve();
    return 0;
}
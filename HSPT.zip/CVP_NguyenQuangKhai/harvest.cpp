#include <bits/stdc++.h>

#define ll long long
#define fi first
#define se second
#define len(s) (ll) s.size()
#define LS(x) (1LL << x)
#define Lg(x) (x > 0 ? 31 - __builtin_clz(x) : 0)

const ll I = 3e5 + 9;
const ll Z = 1e9 + 7;
const ll inf = 1e15;

using namespace std;

template <typename U, typename V>
bool maxz(U &a, V b) { return a < b ? a = b, 1 : 0; }
template <typename U, typename V>
bool minz(U &a, V b) { return a > b ? a = b, 1 : 0; }

ll n, t1, t2, t3;

ll cal(ll a, ll b, ll n)
{
    if (b >= a)
        return a + b * n;
    return (n * a + b);
}

void sub1()
{
    ll m1 = t1 * 2;  // time machine 1
    ll m2 = t1 + t2; // time machine 2
    cout << max(m1, m2) + t3;
}

void sub2()
{
    cout << cal(2, t3, n);
}

void sub3()
{
    cout << 1 + cal(t2, t3, n);
}

void sub_heuris()
{
    cout << cal(2 * t1, t3, n);
}

// #define pii pair<int, int>
// #define vi vector<int>

// namespace sub67
// {
//     vector<vector<vi>> dp;
//     priority_queue<pair<pii, pii>> pq;

//     void solve()
//     {
//         dp.assign(n + 9, vector<vi>(n + 9, vi(n + 9, Z)));
//         dp[0][0][0] = 0;
//         pq.push({{0, 0}, {0, 0}});
//         while (!pq.empty())
//         {
//             int D = -pq.top().fi.fi, m1 = pq.top().fi.se, m2 = pq.top().se.fi, m3 = pq.top().se.se;
//             pq.pop();
//             if (D > dp[m1][m2][m3])
//                 continue;
//             if (m3 == n)
//             {
//                 cout << D;
//                 break;
//             }
//             int m1_ = dp[m1][m2][m3] + t1;
//             m1_ = m1_ / t1;
//             if (minz(dp[min(n, m1_)][m2][m3], dp[m1][m2][m3] + t1))
//                 pq.push({{-dp[min(n, m1_)][m2][m3], m1_}, {m2, m3}});
//             if (m1 > 0)
//             {
//                 int nt = dp[m1][m2][m3] + t2, nm1 = (nt / t1) - m2 - 1 - m3;
//                 minz(nm1, n);
//                 if (minz(dp[nm1][m2 + 1][m3], dp[m1][m2][m3] + t2))
//                     pq.push({{-dp[nm1][m2 + 1][m3], nm1}, {m2 + 1, m3}});
//             }
//             if (m1 > 0 && m2 > 0)
//             {
//                 int nt = dp[m1][m2][m3] + t3;
//                 int nm1 = (nt / t1) - m2 - m3;
//                 int nm2 = m2 - 1;
//                 minz(nm1, n);
//                 if (minz(dp[nm1][nm2][m3 + 1], dp[m1][m2][m3] + t3))
//                     pq.push({{-dp[nm1][nm2][m3 + 1], nm1}, {nm2, m3 + 1}});
//             }
//             if(m1 > 1 && m2 > 0)
//             {
//                 int nt = 
//             }
//         }
//     }
// }

int main()
{
#define TN "harvest"
    if (fopen(TN ".inp", "r"))
    {
        freopen(TN ".inp", "r", stdin);
        freopen(TN ".out", "w", stdout);
    }
    cin.tie(0)->sync_with_stdio(0);
    cin >> n;
    cin >> t1 >> t2 >> t3;
    if (n == 1)
        sub1();
    else if (t1 == t2 && t1 == 1)
        sub2();
    else if (t1 == 1 && t2 > t1)
        sub3();
    else 
    if(t1 == t2)
        sub_heuris();
    // else if (n <= 100)
    //     sub67::solve();
    return 0;
}
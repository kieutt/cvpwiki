#include <bits/stdc++.h>

#define ll long long
#define fi first
#define se second
#define len(s) (ll) s.size()
#define LS(x) (1LL << x)
#define Lg(x) (x > 0 ? 31 - __builtin_clz(x) : 0)

const ll I = 3e5 + 9;
const ll Z = 1e9 + 7;
const ll inf = 1e15;

using namespace std;

template <typename U, typename V>
bool maxz(U &a, V b) { return a < b ? a = b, 1 : 0; }
template <typename U, typename V>
bool minz(U &a, V b) { return a > b ? a = b, 1 : 0; }

int n, m;
string s, t;

bool check(string s, string t)
{
    sort(s.begin(), s.end());
    sort(t.begin(), t.end());
    if (s != t)
        return false;
    return true;
}

namespace sub123
{
    void solve()
    {
        int pos = 0, cur = 0;
        vector<int> ans;
        for (int i = 1; i <= n; i++)
            if (s[i - 1] == t[0])
            {
                pos = i - 1;
                break;
            }
        while (cur < len(t) - 1)
        {
            while (s[n - 1] != t[cur + 1] || pos + cur >= n - 1)
            {
                if (s[n - 1] == t[0])
                    pos = 0;
                else
                    pos++;
                ans.push_back(1);
                s = s[n - 1] + s.substr(0, n - 1);
            }

            int att = pos + cur + 1;
            int p = n - att;
            if (p == 1)
            {
                cur++;
                continue;
            }
            ans.push_back(p);
            string rem = s.substr(att, n - att);
            reverse(rem.begin(), rem.end());
            s = rem + s.substr(0, att);
            pos += n - att;
            cur++;
        }
        cout << len(ans) << "\n";
        for (auto z : ans)
            cout << z << " ";
    }
}

int main()
{
#define TN "shiftrev"
    if (fopen(TN ".inp", "r"))
    {
        freopen(TN ".inp", "r", stdin);
        freopen(TN ".out", "w", stdout);
    }
    cin.tie(0)->sync_with_stdio(0);
    cin >> n >> m;
    cin >> s >> t;
    if (check(s, t) == false)
    {
        cout << -1;
        return 0;
    }
    if (m == 10000)
        sub123::solve();
    return 0;
}
#include <bits/stdc++.h>
#define NAME "hades"
#define ll long long
#define fi first
#define se second
#define vec vector
#define SZ(a) (int)a.size()
#define ALL(a) (a).begin(),(a).end()
using namespace std;
const int N=2e5+5;
int n,m;
vec<array<int,3>> eg;
void INIT(){
    cin>>n>>m;
    eg.resize(m);
    for(auto& i:eg) cin>>i[0]>>i[1]>>i[2];
}

namespace SUB1{
    bool CHKSUB(){return n<=10&&m<=15;}
    vec<int> g[N],gn[N];
    bool vis[N];
    void dfs(int u){
        vis[u]=1;
        for(const int& v:gn[u]){
            if(!vis[v]) dfs(v);
        }
    }
    ll calc(int x,int y){
        ll ret=1e18;
        for(int cur=1;cur<(1<<m);cur++){
            for(int i=0;i<=n;i++) gn[i].clear();

            ll sum=0;
            bool ok=1;
            int dfsf=0;
            for(int i=0;i<m;i++){
                if(!(cur>>i&1)) continue;
                int u=eg[i][0],v=eg[i][1],w=eg[i][2];
                if((u==x&&v==y)||(u==y&&v==x)){
                    ok=0;
                    break;
                }
                sum+=w;
                if(u==x||u==y) u=0;
                if(v==x||v==y) v=0;
                gn[u].emplace_back(v);
                gn[v].emplace_back(u);
                dfsf=u;
            }
            if(!ok) continue;
            fill(vis+1,vis+n+1,0);
            dfs(dfsf);
            for(int i=0;i<=n;i++){
                if(gn[i].empty()) continue;
                if(!vis[i]){
                    ok=0;
                    break;
                }
            }
            if(!ok) continue;
            ret=min(ret,sum);
        }
        return ret;
    }
    void SOLVE(){
        for(int i=0;i<m;i++){
            int u=eg[i][0],v=eg[i][1];
            g[u].push_back(v);
            g[v].push_back(u);
        }
        for(int i=1;i<=n;i++){
            int ans=1e9;
            ll sum=1e18;
            for(const int& v:g[i]){
                ll t=calc(i,v);
                if(sum>t){
                    sum=t;
                    ans=v;
                }
                else if(sum==t) ans=min(ans,v);
            }
            cout<<ans<<' ';
        }
    }
}

namespace SUB7{
    bool CHKSUB(){return 1;}
    vec<int> g[N];
    void SOLVE(){
        multiset<int> s;
        for(int i=0;i<m;i++){
            int u=eg[i][0],v=eg[i][1],w=eg[i][2];
            g[u].push_back(i);
            g[v].push_back(i);
            s.insert(w);
        }
        for(int i=1;i<=n;i++){
            int ans=1e9;
            ll sum=1e18;
            for(const int& j:g[i]){
                int v=eg[j][0]^eg[j][1]^i,w=eg[j][2];
                s.erase(s.find(w));
                if(SZ(s)){
                    ll t=*s.begin();
                    if(sum>t){
                        sum=t;
                        ans=v;
                    }
                    else if(sum==t) ans=min(ans,v);
                }
                s.insert(w);
            }
            cout<<ans<<' ';
        }
    }
}
int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    if(fopen(NAME ".inp","r")){
        freopen(NAME ".inp","r",stdin);
        freopen(NAME ".out","w",stdout);
    }
    INIT();
    if(SUB1::CHKSUB()) return SUB1::SOLVE(),0;
    if(SUB7::CHKSUB()) return SUB7::SOLVE(),0;

}

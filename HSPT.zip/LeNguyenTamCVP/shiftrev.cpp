#include <bits/stdc++.h>
#define NAME "shiftrev"
#define ll long long
#define fi first
#define se second
#define vec vector
#define SZ(a) (int)a.size()
#define ALL(a) (a).begin(),(a).end()
using namespace std;
int n,m;
string s,t;
void INIT(){
    cin>>n>>m>>s>>t;
}

bool CHECK(string s,string t){
    sort(ALL(s));
    sort(ALL(t));
    return s==t;
}

namespace SUB1{
    bool CHKSUB(){return n<=8;}
    map<string,int> f;
    queue<pair<string,int>> q;
    string change(string s,int x){
        string t;
        while(x--){
            t+=s.back();
            s.pop_back();
        }
        return t+s;
    }
    string rchange(string s,int x){
        string ret;
        for(int i=x;s[i];i++) ret+=s[i];
        string t=s.substr(0,x);
        reverse(ALL(t));
        return ret+t;
    }

    void SOLVE(){
        f[s]=0;
        q.push({s,0});
        while(SZ(q)){
            string u=q.front().fi;
            int dst=q.front().se;
            q.pop();
            if(dst==m) continue;
            for(int x=1;x<=n;x++){
                string t=change(u,x);
                if(f.find(t)!=f.end()) continue;
                f[t]=x;
                q.push({t,dst+1});
            }
        }
        if(f.find(t)==f.end()){
            cout<<-1;
            return;
        }
        vec<int> ans;
        int cur=f[t];
        while(cur){
            ans.push_back(cur);
            t=rchange(t,cur);
            cur=f[t];
        }
        reverse(ALL(ans));
        cout<<SZ(ans)<<'\n';
        for(const int& i:ans) cout<<i<<' ';
    }
}

namespace SUB2{
    bool CHKSUB(){return n<=200;}
    const int BASE=311,MOD=1e9+9277;
    int has(const string &s){
         int ret=0;
         for(const auto& i:s) ret=(1ll*ret*BASE+i)%MOD;
         return ret;
    }

    unordered_map<int,pair<int,int>> f;
    queue<pair<string,int>> q;
    string change(string s,int x){
        string t;
        while(x--){
            t+=s.back();
            s.pop_back();
        }
        return t+s;
    }
    string rchange(string s,int x){
        string ret;
        for(int i=x;s[i];i++) ret+=s[i];
        string t=s.substr(0,x);
        reverse(ALL(t));
        return ret+t;
    }

    void SOLVE(){
        int ht=has(t);
        f[has(s)]={0,0};
        q.push({s,0});
        while(SZ(q)){
            string u=q.front().fi;
            int dst=q.front().se;
            q.pop();
            if(dst==m) continue;
            int hu=has(u);
            if(ht==hu) continue;
            for(int x=1;x<=n;x++){
                string t=change(u,x);
                int ht=has(t);
                if(f.find(ht)!=f.end()) continue;
                f[ht]={hu,x};
                q.push({t,dst+1});
            }
        }
        if(f.find(has(t))==f.end()){
            cout<<-1;
            return;
        }
        vec<int> ans;
        pair<int,int> cur=f[has(t)];
        while(cur.se){
            ans.push_back(cur.se);
            cur=f[cur.fi];
        }
        reverse(ALL(ans));
        cout<<SZ(ans)<<'\n';
        for(const int& i:ans) cout<<i<<' ';
    }
}



int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    if(fopen(NAME ".inp","r")){
        freopen(NAME ".inp","r",stdin);
        freopen(NAME ".out","w",stdout);
    }
    INIT();
    if(!CHECK(s,t)){
        cout<<-1;
        return 0;
    }
    if(SUB1::CHKSUB()) return SUB1::SOLVE(),0;
    if(SUB2::CHKSUB()) return SUB2::SOLVE(),0;
    SUB2::SOLVE();
}

#include <bits/stdc++.h>
#define NAME "harvest"
#define ll long long
#define fi first
#define se second
#define SZ(a) (int)a.size()
#define ALL(a) (a).begin(),(a).end()
using namespace std;
int n,t1,t2,t3;
void INIT(){
    cin>>n>>t1>>t2>>t3;
}

namespace SUB1{
    bool CHKSUB(){return n==1;}
    void SOLVE(){
        cout<<t1+max(t1,t2)+t3;
    }
}

namespace SUB2{
    bool CHKSUB(){return t1==1&&t2==1;}
    void SOLVE(){
        int c1=0,c2=0,c3=0;
        int u1=0,u2=0,u3=0;
        int ans=0;
        while(c3<n){
            u1++;
            if(u1==t1){
                c1++;
                u1=0;
            }

            if(u3==t3){
                c3++;
                u3=-1;
            }
            if(u3==0&&c1>0&&c2>0){
                c1--;
                c2--;
                u3++;
            }
            if(u3>0) u3++;

            if(u2==t2){
                c2++;
                u2=0;
            }
            if(u2==0&&c1>0){
                c1--;
                u2++;
            }
            if(u2!=0) u2++;
            ans++;
        }
        cout<<ans;
    }
}


int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    if(fopen(NAME ".inp","r")){
        freopen(NAME ".inp","r",stdin);
        freopen(NAME ".out","w",stdout);
    }
    INIT();
    if(SUB1::CHKSUB()) return SUB1::SOLVE(),0;
    return SUB2::SOLVE(),0;
}

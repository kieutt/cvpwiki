#include <bits/stdc++.h>
#define int long long
#define FOR(i,l,r) for (int i = l; i <= r; ++ i)
#define FORD(i,r,l) for (int i = r; i >= l; -- i)
#define ii pair<int, int>
#define fi first
#define se second
#define pb push_back
using namespace std;


const int MAXN = 2e5 + 5;
const int oo = 1e9 + 7;

int n, m;
vector <ii> adj[MAXN];
// tim cay khung nho nhat
struct Edge {
  int u, v, w;
}E[MAXN];

bool cmp (Edge a, Edge b) {
  return a.w < b.w;
}

namespace SUB1 {

  struct DSU {

    int pa[MAXN];
    int sz[MAXN];

    void reset () {
      FOR (u, 1, n) {
        pa[u] = u;
        sz[u] = 1;
      }
    }

    int f (int u) {
      if (u == pa[u]) return u;
      return pa[u] = f (pa[u]);
    }

    bool join (int u, int v) {
      v = f (v);
      u = f (u);
      if (u == v) return false;
      if (sz[u] < sz[v]) swap (u, v);
      sz[u] += sz[v];
      pa[v] = u;
      return true;
    }

  }dsu;

  void SOLVE () {
    sort (E + 1, E + m + 1, cmp);
    FOR (u, 1, n) {
      int ans = oo, ma = oo;
      for (ii nxt : adj[u]) {
        int v = nxt.fi;
        dsu.reset ();
        int cur = 0;
        FOR (i, 1, m) {
          int v1, v2;
          if (E[i].u == u || E[i].u == v) v1 = u;
          else v1 = E[i].u;
          if (E[i].v == u || E[i].v == v) v2 = u;
          else v2 = E[i].v;
          if (dsu.join (v1, v2)) cur += E[i].w;
        }
        if (cur < ma) {
          ma = cur;
          ans = v;
        }
        else if (cur == ma) ans = min (ans, v);
      }
      cout << ans << ' ';
    }
  }
}

namespace SUB2 {
  void SOLVE () {
    FOR (u, 1, n) {
      int ans = oo;
      int ma = 0;
      for (ii nxt : adj[u]) {
        int v = nxt.fi;
        int w = nxt.se;
        if (w > ma) {
          ans = v;
          ma = w;
        }
        else if (w == ma) ans = min (ans, v);
      }
      cout << ans << ' ';
    }
  }
}

namespace SUB3 {
  void SOLVE () {

  }
}

main () {
    ios_base::sync_with_stdio (0);
    cout.tie (0);
    freopen ("hades.inp", "r", stdin);
    freopen ("hades.out", "w", stdout);
    cin >> n >> m;
    FOR (i, 1, m) {
      int u, v, w;
      cin >> u >> v >> w;
      if (u > v) swap (u, v);
      adj[u].pb ({v, w});
      adj[v].pb ({u, w});
      E[i] = {u, v, w};
    }
    if (n <= 10 && m <= 15) SUB1 :: SOLVE ();
    else if (m == n - 1) SUB2 :: SOLVE ();
    else SUB1 :: SOLVE ();
    return 0;
}

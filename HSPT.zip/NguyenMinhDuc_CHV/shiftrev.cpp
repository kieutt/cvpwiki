#include <bits/stdc++.h>
#define int long long
#define FOR(i,l,r) for (int i = l; i <= r; ++ i)
#define FORD(i,r,l) for (int i = r; i >= l; -- i)
using namespace std;

main () {
    ios_base::sync_with_stdio (0);
    cout.tie (0);
    freopen ("shiftrev.inp", "r", stdin);
    freopen ("shiftrev.out", "w", stdout);
    cout << -1;
    return 0;
}


#include <bits/stdc++.h>
#define int long long
#define ll long long
#define FOR(i,l,r) for (int i = l; i <= r; ++ i)
#define FORD(i,r,l) for (int i = r; i >= l; -- i)
using namespace std;

int n, t1, t2, t3;

namespace SUB1 {
  void SOLVE () {
    cout << t1 + t2 + max (t1 - t2, 0ll) + t3;
  }
}

namespace SUB2 {
  void SOLVE () {
    cout << t1 + t2 + t3 * n;
  }
}

namespace SUB3 {
  void SOLVE () {
    if (t1 == t2 && t2 == t3) cout << 3 + 2 * (n - 1);
    else if (t3 > t2) cout << t1 + t2 + t3 * n;
    else cout << t1 + t3 + t2 * n;
  }
}

namespace SUB4 {
  void SOLVE () {
    cout << t1 + t2 * n + t3;
  }
}

namespace SUB5 {
  void SOLVE () {
    cout << t1 + t2 + t3 * n;
  }
}

namespace SUB678 {
  void SOLVE () {
    if (t1 < t2) {
      if (t2 > t3) cout << t1 + t2 * n + t3;
      else cout << t1 + t2 + t3 * n;
    }
    else {

    }
  }
}

main () {

    ios_base::sync_with_stdio (0);
    cout.tie (0);
    freopen ("harvest.inp", "r", stdin);
    freopen ("harvest.out", "w", stdout);
    cin >> n >> t1 >> t2 >> t3;
    if (n == 1) SUB1 :: SOLVE ();
    else if (t1 == t2 && t2 == 1 && t3 > 2) SUB2 :: SOLVE ();
    else if (t1 == 1) SUB3 :: SOLVE ();
    else if (t1 == t2 && t2 > t3) SUB4 :: SOLVE ();
    else if (t1 == t2) SUB5 :: SOLVE ();
    else SUB678 :: SOLVE ();
    return 0;
}


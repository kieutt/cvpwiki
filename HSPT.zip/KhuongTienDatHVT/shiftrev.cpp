#include <bits/stdc++.h>
#define int long long
using namespace std;
int n, m, slt[28], sls[28];
string s, t;
vector<int> vec;
int32_t main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("shiftrev.inp","r",stdin);
    freopen("shiftrev.out","w",stdout);
    cin >> n >> m;
    cin >> s >> t;
    for (char ch : s)
    {
        sls[ch - 'a']++;
        vec.push_back(ch - 'a');
    }
    for (char ch : t)
    {
        slt[ch - 'a']++;
        vec.push_back(ch - 'a');
    }
    cout << -1;
    return 0;
}

#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 1000;
int n, t1, t2, t3;

namespace sub1
{
    void solve()
    {
        cout << t1 + max(t1, t2) + t3;
    }
}

namespace sub2
{
    void solve()
    {
        cout << n*t3+2;
    }
}

namespace sub3
{
    void solve()
    {
        cout << (t1+t2+t3) + (max(0, t2 - t3) + t3) * (n-1);
    }
}

namespace sub4
{
    void solve()
    {
        cout << (t1 + t2 + t3) + (t1 - 1 + t2 + t3) * (n-1);
    }
}

namespace sub5
{
    void solve()
    {
        if (t3 / t1 >= 2)
        {
            cout << t1 + t2 + t3 + t3 * (n-1);
        }
        else
        {
            cout << t1 + t2 + t3 + (t1 - (t3%t1) + t3) * (n-1);
        }
    }
}

namespace sub6
{
    ll ans = 0, tt1, tt2, tt3, sl1, sl2, dangxuli2, dangxuli3;
    void solve()
    {
        while (n)
        {
            ans++;
            tt1++;
            if (tt1 == t1)
            {
                sl1++;
                tt1 = 0;
            }
            if (!dangxuli2 && sl1)
            {
                sl1--;
                dangxuli2 = 1;
            }
            else if (dangxuli2)
            {
                tt2++;
                if (tt2 == t2)
                {
                    sl2++;
                    tt2 = 0;
                    dangxuli2 = 0;
                }
            }
            if (!dangxuli3 && sl1 && sl2)
            {
                sl1--;
                sl2--;
                dangxuli3 = 1;
            }
            else if (dangxuli3)
            {
                tt3++;
                if (tt3 == t3)
                {
                    n--;
                    tt3 = 0;
                    dangxuli3 = 0;
                }
            }
        }
        cout << ans;
    }
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("harvest.inp","r",stdin);
    freopen("harvest.out","w",stdout);
    cin >> n >> t1 >> t2 >> t3;
    if (n == 1)
        sub1::solve();
    else if (t1 == t2 && t1 == 1)
        sub2::solve();
    else if (t1 == 1)
        sub3::solve();
    else if (t1 == t2 && t1 > t3)
        sub4::solve();
    else if (t1 == t2 && t1 == 2)
        sub5::solve();
    else
        sub6::solve();
    return 0;
}

#include <bits/stdc++.h>
#define int long long
#define pii pair<int, int>
using namespace std;
const int N = 2e5, inf = 1e18;
int n, m, lab[N+2];
pii canhmax[N+2];
vector<pii> adj[N+2];
struct gido
{
    int u, v, w;
};
vector<gido> duong;
bool cmp(gido a, gido b)
{
    a.w < b.w;
}
namespace sub1
{
    int find_set(int u)
    {
        return (lab[u] < 0 ? u : lab[u] = find_set(lab[u]));
    }
    bool join(int u, int v)
    {
        u = find_set(u);
        v = find_set(v);
        if (v!=u)
        {
            lab[u]+= lab[v];
            lab[v] = u;
            return true;
        }
        return false;
    }
    int kruskal(int x, int y)
    {
        int res = 0;
        for (gido cur : duong)
        {
            int temp1 = cur.u, temp2 = cur.v;
            if (cur.u == y)
            {
                temp1 = x;
            }
            if (cur.v == y)
            {
                temp2 = x;
            }
            if (join(temp1, temp2)) res += cur.w;
        }
        return res;
    }
    void solve()
    {
        sort(duong.begin(), duong.end(), cmp);
        int h = inf;
        for (int i = 1; i <= n; i++)
        {
            int ans = inf;
            for (pii j : adj[i])
            {
                memset(lab, -1, sizeof lab);
                ans = min(ans, kruskal(i, j.second));
            }
            for (pii j : adj[i])
                if (j.first == ans) h = min(h, j.second);
            cout << h << ' ';
        }
    }
}
int32_t main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("hades.inp","r",stdin);
    freopen("hades.out","w",stdout);
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back({w, v});
        adj[v].push_back({w, u});
        duong.push_back({u, v, w});
        if (canhmax[u].first < w) canhmax[u] = {w, v};
        else if (canhmax[u].first == w) canhmax[u].second = min(canhmax[u].second, v);
        if (canhmax[v].first < w) canhmax[v] = {w, u};
        else if (canhmax[v].first == w) canhmax[v].second = min(canhmax[v].second, u);
    }
//    if (n <= 10 && m <= 15)
//        sub1::solve();
//    else
    for (int i = 1; i <= n; i++)
    {
        cout << canhmax[i].second << ' ';
    }
    return 0;
}

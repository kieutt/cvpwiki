#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
int const N=2e5+5;
int n,m;
string s,t;
void sol(){
  cin>>n>>m;
  cin>>s>>t;
  if(s==t){
    cout<<0<<endl;
    return;
  }

  cout<<-1<<endl;
}

int main(){
  #define ts "shiftrev"
  if(fopen(ts".inp","r")){
    freopen(ts".inp","r",stdin);
    freopen(ts".out","w",stdout);
  }
  ios_base::sync_with_stdio(0);
  cin.tie(NULL);
  sol();
}

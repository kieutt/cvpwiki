#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll n,t1,t2,t3;
void sol(){
 cin>>n>>t1>>t2>>t3;
 vector<ll> hu;
 hu.push_back(-1e18);
 for(int i=1;i<=n;++i){
    ll cur=t1*i,last=hu[hu.size()-1];
    hu.push_back(max(cur,last) + t2);
 }
 vector<ll> res;
 res.push_back(-1e18);
 for(int i=1;i<=n;++i){
    ll cur=t1*(i+n),sp2=hu[i],last=res[res.size()-1];
    res.push_back(max({cur,sp2,last})+t3);
 }
 cout<<res[res.size()-1]<<endl;
}

int main(){
  #define ts "harvest"
  if(fopen(ts".inp","r")){
    freopen(ts".inp","r",stdin);
    freopen(ts".out","w",stdout);
  }
  ios_base::sync_with_stdio(0);
  cin.tie(NULL);
  sol();
}

#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
int const N=2e5+5;
int n,m,par[N],ma[N][20],cha[N][20],h[N];
ll sum=0;
bool mst[N];
vector<pair<int,int>> d[N];
struct cung{
 int val,x,y;
};
int get(int u){return u==par[u]? u: par[u]=get(par[u]);}

vector<cung> siu;
bool cmp(cung &a,cung &b){
 return a.val<b.val;
}
void dfs(int u,int p){
  for(pair<int,int> v:d[u]){
     if(p==v.first || !mst[v.second]) continue;
     h[v.first]=h[u]+1;
     ma[v.first][0]=siu[v.second].val;
     cha[v.first][0]=u;
     dfs(v.first,u);
  }
}
int lca(int u,int v){
  int ans=0;
  if(h[u]!=h[v]){
  if(h[u]<h[v]) swap(u,v);
  for(int i=19;i>=0;--i){
    if(h[u]-(1<<i) >=h[v]){
        ans=max(ans,ma[u][i]);
        u=cha[u][i];
    }
  }
  }
  if(u==v) return ans;
  for(int i=19;i>=0;--i){
    if(cha[u][i] !=cha[v][i]){
        ans=max({ans,ma[u][i],ma[v][i]});
        u=cha[u][i];
        v=cha[v][i];
    }
  }
  return max({ans,ma[u][0],ma[v][0]});
}
void sol(){
cin>>n>>m;
for(int i=1;i<=n;++i) par[i]=i;
for(int i=0,u,v,w;i<m;++i){
    cin>>u>>v>>w;
    siu.pb({w,u,v});
}
sort(begin(siu),end(siu),cmp);
for(int i=0,u,v;i<m;++i){
   u=siu[i].x,v=siu[i].y;
   d[u].pb({v,i});
   d[v].pb({u,i});
}

for(int i=0;i<m;++i){
    int a=get(siu[i].x),b=get(siu[i].y);
    if(a!=b){
        sum+=siu[i].val;
        mst[i]=1;
        par[a]=b;
    }
}
dfs(1,0);
for(int i=1;i<20;++i){
    for(int j=1;j<=n;++j){
        cha[j][i]=cha[cha[j][i-1]][i-1];
        ma[j][i]=max(ma[j][i-1],ma[cha[j][i-1]][i-1]);
    }
}
for(int u=1;u<=n;++u){
    ll ans=1e18;
    int id=1e9;
    for(pair<int,int> v:d[u]){
        ll new_sum=sum-lca(v.first,u);
        if(new_sum<ans) ans=new_sum,id=v.first;
        else if(new_sum==ans) id=min(id,v.first);
    }
    cout<<id<<" ";
}
}

int main(){
  #define ts "hades"
  if(fopen(ts".inp","r")){
    freopen(ts".inp","r",stdin);
    freopen(ts".out","w",stdout);
  }
  ios_base::sync_with_stdio(0);
  cin.tie(NULL);
  sol();
}

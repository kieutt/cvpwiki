#include<bits/stdc++.h>
#define ll long long
#define fast ios_base::sync_with_stdio(0), cin.tie(0);

using namespace std;

main(){
    fast
    if(fopen("harvest.inp","r")){
        freopen("harvest.inp","r",stdin);
        freopen("harvest.out","w",stdout);
    }
    // ti check b1 lai vi sub cuoi hoi loi
    long long n;
    cin >> n;
    long long t1,t2,t3;
    cin >> t1 >> t2 >> t3;

    if(n == 1){
        cout << max(2*t1, t1+t2) + t3;
        return 0;
    }
    if(t1 == t2){
        if(t3 >= 2*t1) cout << max(n*2*t1, 2*t1 + n*t3);
        else cout << n*2*t1 + t3;
        return 0;
    }

    if(t1 == 1){
        if(t2 <= t3) cout << max( 1+t2+n*t3, 2*n);
        else cout << max(2*n, 1+n*t2+t3);
        return 0;
    }

    long long d1=0, d2=-1, d3=-1;
    long long cnt1 = 0, cnt2 = 0, cnt3 = 0;

    for(long long x=1; x<=2e8; x++){
        //cout << d1 << " " << cnt1 << "\n";
        //cout << d2 << " " << cnt2 << "\n";
        //cout << d3 << " " << cnt3 << "\n";
        //cout << "\n";
        ++d1;
        if(d1 == t1){
            cnt1++, d1 = 0;
        }
        if(cnt1 > 0){
            ++d2;
            if(d2 == t2){
            cnt2++, cnt1--, d2 = 0;
            }

        }

        if(cnt1 > 0 && cnt2 > 0){
            ++d3;

            if(d3 == t3){
            cnt3++, cnt2--, cnt1--, d3 = 0;
            }
        }

        if(cnt3 == n){
            cout << x;
            return 0;
        }
    }

    return 0;
}
/*
1
1 5 6

1000
2 1000 100000
-> 100001002

1
2 1000 100000

10
2 2 100
*/


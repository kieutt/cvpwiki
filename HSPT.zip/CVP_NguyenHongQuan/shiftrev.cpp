#include<bits/stdc++.h>
#define ll long long
#define fast ios_base::sync_with_stdio(0), cin.tie(0);

using namespace std;

main(){
    fast
    if(fopen("shiftrev.inp","r")){
        freopen("shiftrev.inp","r",stdin);
        freopen("shiftrev.out","w",stdout);
    }
    int n,m;
    cin >> n >> m;

    string s,t;
    cin >> s >> t;
    cout << -1;
    return 0;
}
/*

*/



#include<bits/stdc++.h>
#define ll long long
#define fast ios_base::sync_with_stdio(0), cin.tie(0);
#define pii pair<long long,long long>
#define fi first
#define se second
using namespace std;
const long long N = 2e5;
struct ok{
long long u,v,w;
};
bool cmp(ok a, ok b){
    return a.w < b.w;
}

vector<ok> canh;
vector<pii> g[N+5];


long long pa[N+5], sz[N+5];
long long f1(long long u){
    if(u == pa[u]) return u;
    return pa[u] = f1(pa[u]);
}

void gop(long long u, long long v){
    long long x = f1(u), y = f1(v);
    if(x == y) return;
    if(sz[y] > sz[x]) swap(x,y);
    sz[x] += sz[y];
    pa[y] = x;
}

main(){
    fast
    if(fopen("hades.inp","r")){
        freopen("hades.inp","r",stdin);
        freopen("hades.out","w",stdout);
    }

    long long n,m;
    cin >> n >> m;
    for(long long i=1; i<=m; i++){
        long long u,v,w;
        cin >> u >> v >> w;
        g[u].push_back({v,w});
        g[v].push_back({u,w});
        canh.push_back({u,v,w});
    }
    // sub2, cac trong so phan biet
    if(m == n-1){

        for(long long u=1; u<=n ;u++){
            long long ma = 0, kq = n+5;
            for(auto [v,w]:g[u]){
                if(ma < w){
                    kq = v, ma = w;
                }
            }
            cout << kq << " ";
        }
        return 0;
    }

    if(m <= 5000){
        vector<ll> kq(n+5, n+5);
        vector<ll> so(n+5, 1e16);

        sort(canh.begin(), canh.end(), cmp);

        vector<ok> canh1;
        for(auto [u,v,w] : canh){
            // lam cay mst
            canh1.clear();
            for(long long i=1; i<=n ;i++){
                pa[i] = i, sz[i] = 1;
            }

            for(auto [x,y,z] : canh)
                if(x != u || y != v){
                    canh1.push_back({x,y,z});
                }
            ll res = 0;
            for(auto [x,y,z] : canh1){
                if(f1(x) == f1(y)) continue;
                res += z;
                gop(x,y);
            }
            //cout << u << " " << v << " " << w << " " << res << "\n";

            if(so[u] > res) kq[u] = v;
            else if(so[u] == res) kq[u] = min(kq[u], v);

            if(so[v] > res) kq[v] = u;
            else if(so[v] == res) kq[v] = min(kq[v], u);

            canh1.clear();
            // lam xong nho clear cac mang
        }
        for(long long u=1; u<=n; u++) cout << kq[u] << " ";
        return 0;
    }
    // ti chuyen het long long -> long long
    return 0;
}
/*
3 3
1 2 1
2 3 2
1 3 3
-> 3 3 1

4 3
1 2 1
2 3 6
2 4 5
-> 2 3 2 2
*/


#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define fi first
#define se second
#define sz(x) x.size()
#define pb push_back

int n, m;
string s, t;
vector <int> ans;

bool check (string &x, int rm){
    if (x == s) return true;
    if (rm == 0) return false;

    for (int i = 0; i < sz(x); i++){
        string nw = x.substr (0, i);
        string y = x.substr (i);
        reverse (y.begin(), y.end());
        nw = y + nw;
        if (check (nw, rm - 1)){
            ans.pb (sz(x) - i);
            return 1;
        }
    }
}

int main (){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    #define task "shiftrev"
    if (fopen (task ".inp", "r")){
        freopen (task ".inp", "r", stdin);
        freopen (task ".out", "w", stdout);
    }
    cin >> n >> m >> s >> t;
    if (check (t, m)){
        cout << sz(ans) << '\n';
        reverse (ans.begin(), ans.end());
        for (auto z : ans) cout << z << ' ';
    } else {
        cout << -1 << '\n';
    }

    return 0;
}

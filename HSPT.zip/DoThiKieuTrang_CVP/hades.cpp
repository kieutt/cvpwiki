#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define fi first
#define se second
#define sz(x) (ll)x.size()
#define pb push_back
typedef pair <int, int> ii;

int n, m, u, v, a;
const int N = 2e5 + 9;
vector <ii> adj[N];

namespace sub2 {
bool check () {
    if (m == n - 1) return true;
    return false;
}

void solve() {
    for (int i = 1; i <= n; i++) {
        sort (adj[i].begin(), adj[i].end(), greater <ii>());
        cout << adj[i][0].se << ' ';
    }
}
}

namespace sub1 {
bool check () {
    if (n <= 10 && m <= 15) return true;
    else return false;
}

vector <bool> vis;

ll prim(int x, int y) {
    vis.assign (n + 9, 0);
    priority_queue <ii, vector <ii>, greater <ii> > pq;
    pq.push ({0, 1});

    ll dem = 0, res = 0;

    while (!pq.empty()) {
        ll w = pq.top().fi;
        int u = pq.top().se;
        int v = 0;
        if (u == x) v = y;
        if (u == y) v = x;

        pq.pop();
        if (vis[u]) continue;
        vis[u] = 1;
        dem++;
        res += w;
        if (v) {
            vis[v] = 1;
            dem++;
        }
        if (dem == n) break;

        for (auto z : adj[u]) {
            if (z.se != v && !vis[z.se]) pq.push (z);
        }
        if (v) {
            for (auto z : adj[v]) {
                if (z.se != u && !vis[z.se]) pq.push (z);
            }
        }
    }
    return res;
}

void solve() {
    for (int i = 1; i <= n; i++) {
        int sl = sz(adj[i]);
        ll ans = 1e9;
        int id;

        for (int j = 0; j < sl; j++) {
            pair <int, int> now = adj[i][j];
            ll nx = prim(i, now.se);
            if (nx < ans) {
                ans = nx;
                id = now.se;
            } else if (nx == ans) id = min (id, now.se);
        }
        cout << id << ' ';
    }
}
}

namespace sub3 {
    bool check (){
        if (m == n) return true;
        return false;
    }

    vector <bool> vis;
    int now = 0, res = 0;

    bool dfs (int u, int pa){
        vis[u] = 1;
        for (auto z: adj[u]){
            if (!vis[z.se]) {
                if (dfs (z.se, u)){
                    res == max (res, z.fi);
                    if (u != now) return 1;
                    else return 0;
                }
            } else if (z.se != pa) {
                now = z.se;
                res = z.fi;
                return 1;
            }
        }
        return 0;
    }

    void solve(){
        vis.resize (n + 9, 0);
        dfs(1, 0);
        for (int i = 1; i <= n; i++){
            sort (adj[i].begin(), adj[i].end(), greater <ii>());
            if (adj[i][0].fi == res){
                if (sz(adj[i]) == 1){
                    cout << adj[i][0].se << ' ';
                } else {
                    cout << adj[i][1].se << ' ';
                }
            } else {
                cout << adj[i][0].se << ' ';
            }
        }
    }
}

int main () {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
#define task "hades"
    if (fopen (task ".inp", "r")) {
        freopen (task ".inp", "r", stdin);
        freopen (task ".out", "w", stdout);
    }
    cin >> n >> m;
    for (int i = 1; i <= m; i++) {
        cin >> u >> v >> a;
        adj[u].pb ({a, v});
        adj[v].pb ({a, u});
    }
    if (sub2::check()) sub2::solve();
    else sub1::solve();
    //if (sub3::check()) sub3::solve();
    return 0;
}

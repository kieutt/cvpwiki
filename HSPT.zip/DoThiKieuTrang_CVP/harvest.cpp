#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define fi first
#define se second
#define sz(x) x.size()

ll n, t1, t2, t3;

int main (){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    #define task "harvest"
    if (fopen (task ".inp", "r")){
        freopen (task ".inp", "r", stdin);
        freopen (task ".out", "w", stdout);
    }

    cin >> n >> t1 >> t2 >> t3;

    if (n == 1){
        cout << max (t1 * 2, t1 + t2) + t3 << '\n';
        return 0;
    }

    if (t1 >= t2 && t1 >= t3){
        cout << t1 * 2 * n + t3 << '\n';
        return 0;
    }

    if (t1 == t2){
        if (t3 >= t1 + t2) cout << t1 + t2 + t3 * n << '\n';
        else cout << (t1 + t2) * n + t3;
        return 0;
    }

    if (t1 <= t2 / 2){
        cout << max (t3 * n + t1 + t2, t1 + t2 * n + t3) << '\n';
        return 0;
    }

    cout << max ((t1 + t2) * n + t3, t1 + t2 + t3 * n);
    return 0;
}

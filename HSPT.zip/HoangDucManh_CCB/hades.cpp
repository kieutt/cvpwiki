#include<bits/stdc++.h>
using namespace std;
typedef pii = pair<int,int>;
using ll = long long;
int n,m;
const int MAXN = 200005;
vector<pi> adj[MAXN];
int par[MAXN]
int main(){
    freopen("hades.inp", "r", stdin);
    freopen("hades.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
    cin >> n >> m;
    for(int i = 0; i<m; i++){
        int a,b,c;
        cin >> a >> b >> c;
        adj[a].push_back({b,c});
        adj[b].push_back({a.c});
    }

    return 0;
}

#include<bits/stdc++.h>
using namespace std;
using ll = long long;
int n, a,b,c;
int sub1(int t1, int t2, int t3){
    return t1 + t2 + t3;
}
int sub2(int n, int t1, int t2, int t3){
    return t1 + t2+t3*n;
}
int sub3(int n, int t1, int t2, int t3){
    if(t2==t3){
        return t1 + t2 + t3*n;
    }
    else if(t2>t3){
        return t1 + t2 +t3*n+(t2-t3)*(n-1);
    }
    else{
        return t1 + t2 + t3*n;
    }
}
int sub4(int n, int t1, int t2, int t3){
    return t1 + t2 +t3*n+(t2-t3)*(n-1);
}
int sub5(int n, int t1, int t2, int t3){
    if(t1==2){
        return t1 + t2 + t3*n;
    }
    if(t2==4){
        return t1 + t2 + t3*n;
    }
}
int sub6(int n, int t1, int t2, int t3){
    if(t1<t2&&t2<t3){
        return t1 + t2 + t3*n;
    }
    if(t1>t2&&t2>t3){
        return t1*n + t2 + t3;
    }
    if(t1>t2&&t1<t3){
        return t1 + t2 + t3*n;
    }
    if(t1 < t2 && t1 > t3){
        return t1 + t2*n + t3;
    }
}int sub7(int n, int t1, int t2, int t3){
    if(t1<t2&&t2<t3){
        return t1 + t2 + t3*n;
    }
    if(t1>t2&&t2>t3){
        return t1*n + t2 + t3;
    }
    if(t1>t2&&t1<t3){
        return t1 + t2 + t3*n;
    }
    if(t1 < t2 && t1 > t3){
        return t1 + t2*n + t3;
    }
}
int main(){
    freopen("harvest.inp", "r", stdin);
    freopen("harvest.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);cout.tie(nullptr);
    cin >> n;
    cin >> a >> b >> c;
    if(n==1){
        cout << sub1(a, b, c) << "\n";
        return 0;
    }
    if(a==b==1&&c>2){
        cout << sub2(n,a,b,c) << "\n";
        return 0;
    }
    if(a==1){
        cout << sub3(n,a,b,c) << "\n";
        return 0;
    }
    if(a==b&&b>c){
        cout << sub4(n,a,b,c)<<"\n";
        return 0;
    }
    if((a==b&&a==2)||(a==b&&a==4)){
        cout << sub5(n,a,b,c) << "\n";
        return 0;
    }
    if(n<=6 && b<=3 && c<=3){
        cout << sub6(n,a,b,c) << "\n";
        return 0;
    }
    if(n<=100 && b<=100 && c<=100){
        cout << sub7(n,a,b,c) << "\n";
        return 0;
    }
    return 0;
}

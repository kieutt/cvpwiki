#include<bits/stdc++.h>
using namespace std;
using ll = long long;
string s, t;
int n, m;
int main(){
    freopen("shiftrev.inp", "r", stdin);
    freopen("shiftrev.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
    cin >> n >> m >> s >> t;
    cout << -1 << "\n";
    return 0;
}

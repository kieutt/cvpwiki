#include<bits/stdc++.h>

using namespace std;

#define int long long
#define FOR(i, a, b) for(int i = a; i <= b; ++ i)
#define FORD(i, a, b) for(int i = a; i >= b; --i)
#define pb push_back
int n, m;

const int maxN = 2e5 + 5;

struct edge {
    int u, v, w;
} E[maxN];

bool cmp(edge x, edge y) {
    return x.w < y.w;
}

struct disjoint_set_union {

    int sz[maxN], pa[maxN];

    void reset(int u, int v) {
        FOR(i, 1, n) if (i != u) {
            pa[i] = i;
            sz[i] = 1;
        } else {
            pa[i] = v;
            sz[i] = 1;
        }
    }

    int find_set(int x) {
        if (x == pa[x])
            return x;
        return pa[x] = find_set(pa[x]);
    }

    bool union_set(int u, int v) {
        u = find_set(u);
        v = find_set(v);
        if (u == v)
            return 0;
        if (sz[u] < sz[v])
            swap(u, v);
        sz[u] += sz[v];
        pa[v] = u;
        return 1;
    }
} DSU;
const int oo = 1e16;
namespace subdick {
    int cost[5008], opt[5008];

    void xuly(int id) {
        int U = E[id].u, V = E[id].v;
        DSU.reset(U, V);
        int cst = 0;
        FOR(i, 1, m) if (DSU.union_set(E[i].u, E[i].v))
            cst += E[i].w;
        if (cst < cost[U]) {
            cost[U] = cst;
            opt[U] = V;
        } else if (cst == cost[U])
            opt[U] = min(opt[U], V);

        if (cst < cost[V]) {
            cost[V] = cst;
            opt[V] = U;
        } else if (cst == cost[V])
            opt[V] = min(opt[V], U);
    }
    void SOLVE() {
        sort(E + 1, E + m + 1, cmp);

        FOR(i, 1, n)
            cost[i] = oo;

        FOR(i, 1, m)
            xuly(i);

        FOR(i, 1, n)
            cout << opt[i] << " ";
    }
}

namespace SUBtree {
    int cost[maxN], opt[maxN];
    int total = 0;
    void xuly(int id) {
        int U = E[id].u, V = E[id].v;
        int cst = total - E[id].w;
        if (cst < cost[U]) {
            cost[U] = cst;
            opt[U] = V;
        } else if (cst == cost[U])
            opt[U] = min(opt[U], V);

        if (cst < cost[V]) {
            cost[V] = cst;
            opt[V] = U;
        } else if (cst == cost[V])
            opt[V] = min(opt[V], U);
    }

    void SOLVE() {
        FOR(i, 1, m)
            total += E[i].w;
        FOR(i, 1, n)
            cost[i] = oo;
        FOR(i, 1, m)
            xuly(i);

        FOR(i, 1, n)
            cout << opt[i] << " ";
    }
}

namespace SUBonecycle {
    int cost[maxN], opt[maxN];
    int mst = 0;
    bool in_mst[maxN];

    void xuly(int id) {
        int U = E[id].u, V = E[id].v;
        int cst = mst;
        if (in_mst[id])
            cst -= E[id].w;
        else {
            DSU.reset(U, V);
            cst = 0;
            FOR(i, 1, m) if (DSU.union_set(E[i].u, E[i].v))
                cst += E[i].w;
        }

        if (cst < cost[U]) {
            cost[U] = cst;
            opt[U] = V;
        } else if (cst == cost[U])
            opt[U] = min(opt[U], V);

        if (cst < cost[V]) {
            cost[V] = cst;
            opt[V] = U;
        } else if (cst == cost[V])
            opt[V] = min(opt[V], U);
    }

    void SOLVE() {
        DSU.reset(0, 0);
        sort(E + 1, E + m + 1, cmp);
        FOR(i, 1, m) if (DSU.union_set(E[i].u, E[i].v)) {
            in_mst[i] = true;
            mst += E[i].w;
        }

        FOR(i, 1, n)
            cost[i] = oo;

        FOR(i, 1, m)
            xuly(i);

        FOR(i, 1, n)
            cout << opt[i] << " ";
    }
}
//
//namespace SUBcactus {
//    int cost[maxN], opt[maxN];
//    int mst = 0;
//    bool in_mst[maxN];
//
//    int low[maxN], num[maxN];
//
//    vector<int> E[maxN];
//
//    int Time = 0;
//    void dfs(int u, int pre) {
//        ++ Time;
//        for(int id: Edge[])
//    }
//
//    void xuly(int id) {
//        int U = E[id].u, V = E[id].v;
//        int cst = mst;
//        if (in_mst[id])
//            cst -= E[id].w;
//        else {
//            DSU.reset(U, V);
//            cst = 0;
//            FOR(i, 1, m) if (DSU.union_set(E[i].u, E[i].v))
//                cst += E[i].w;
//        }
//
//        if (cst < cost[U]) {
//            cost[U] = cst;
//            opt[U] = V;
//        } else if (cst == cost[U])
//            opt[U] = min(opt[U], V);
//
//        if (cst < cost[V]) {
//            cost[V] = cst;
//            opt[V] = U;
//        } else if (cst == cost[V])
//            opt[V] = min(opt[V], U);
//    }
//
//    void SOLVE() {
//        DSU.reset(0, 0);
//        sort(E + 1, E + m + 1, cmp);
//
//        FOR(i, 1, m) if (DSU.union_set(E[i].u, E[i].v)) {
//            in_mst[i] = true;
//            mst += E[i].w;
//        }
//
//        FOR(i, 1, m) {
//            Edge[E[i].u].pb(i);
//            Edge[E[i].v].pb(i);
//        }
//
//        FOR(i, 1, n)
//            cost[i] = oo;
//
//        FOR(i, 1, m)
//            xuly(i);
//
//        FOR(i, 1, n)
//            cout << opt[i] << " ";
//    }
//}

signed main() {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    freopen("hades.inp", "r", stdin);
    freopen("hades.out", "w", stdout);

    cin >> n >> m;

    FOR(i, 1, m) {
        cin >> E[i].u >> E[i].v >> E[i].w;
    }
    if (m == n - 1)
        SUBtree::SOLVE();
    else if (m <= 5000)
        subdick::SOLVE();
    else if (m == n)
        SUBonecycle::SOLVE();

    return 0;

}

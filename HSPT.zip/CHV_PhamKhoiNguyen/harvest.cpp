#include<bits/stdc++.h>

using namespace std;

#define FOR(i, a, b) for(int i = a; i <= b; ++ i)
#define FORD(i, a, b) for(int i = a; i >= b; --i)

int n;
int t1, t2, t3;

namespace SUB1 {
    void SOLVE() {
        int res = 0;
        res += t1;
        res += max(t1, t2);
        res += t3;
        cout << res;
    }
}

namespace SUB2 {
    void SOLVE() {
        int res = 0;
        res += 2;
        res += n * t3;
        cout << res;
    }
}


namespace SUBlol {

    int cnt = 0;

    void SOLVE() {
        int I = 0, II = 0, III = 0;
        int fact1 = 0, fact2 = -1, fact3 = -1;

        int lim = (t1 + max(t1, t2) + t3) * n;
        FOR(Time, 1, lim) {
            if (fact3 != -1) {
                if (Time - fact3 == t3) {
                    fact3 = -1;
                    ++ III;
                }
            }

            if (III == n) {
                cout << Time;
                return;
            }

            if (fact2 != -1) {
                if (Time - fact2 == t2) {
                    fact2 = -1;
                    ++ II;
                    ++ cnt;

                }
            }

            if (fact1 != -1)
                if (Time - fact1 == t1) {
                    fact1 = -1;
                    ++ I;
                }

            if (fact3 == -1) if (I > 0 && II > 0) {
                -- I;
                -- II;
                fact3 = Time;
            }

            if (fact2 == -1) if (cnt < n) if (I > 0) {
                -- I;
                fact2 = Time;
            }

            if (fact1 == -1) {
                fact1 = Time;
            }

        }
        cout << lim;
    }
}

namespace SUBkid {
    void SOLVE() {
        cout << t3 * n + t1 + t2;
    }
}

signed main() {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);


    freopen("harvest.inp", "r", stdin);
    freopen("harvest.out", "w", stdout);

    cin >> n;

    cin >> t1 >> t2 >> t3;

    if (n == 1)
        SUB1::SOLVE();
    else if (t1 == 1 && t2 == 1 && t3 > 2)
        SUB2::SOLVE();
    else if ((t1 + t2) < t3)
        SUBkid::SOLVE();
    else
        SUBlol::SOLVE();

    return 0;

}

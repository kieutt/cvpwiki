#include<bits/stdc++.h>

using namespace std;

#define int long long
#define FOR(i, a, b) for(int i = a; i <= b; ++ i)
#define FORD(i, a, b) for(int i = a; i >= b; --i)

string S, T;
int n, m;

signed main() {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    freopen("shiftrev.inp", "r", stdin);
    freopen("shiftrev.out", "w", stdout);
    cin >> n >> m;
    cin >> S;
    cin >> T;

    cout << -1;

    return 0;

}

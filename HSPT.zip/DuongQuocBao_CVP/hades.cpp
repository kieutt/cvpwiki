#include<bits/stdc++.h>
#define fi first
#define se second
#define ll long long
using namespace std;
const int N=2e5;
int dp[N+5],sz[N+5],par[N+5];
vector<int> g[N+5];
struct Node {
    int fi,se;ll ba;
};
vector<Node> vec;
bool cmp(Node u1,Node v1){
    return u1.ba<v1.ba;
}
int f(int u){
    if (u==par[u]) return u;
    int p=f(par[u]);
    return par[u]=p;
}
void gop(int u,int v,int w){
    int lu=u,lv=v;
    u=f(u);v=f(v);
    if (u==v) return;
    if (sz[u]<sz[v]) swap(u,v);
    sz[u]+=sz[v];
    par[v]=u;
    dp[max(lu,lv)]=w;
}
int main(){
    if (fopen("hades.inp","r")){
        freopen("hades.inp","r",stdin);
        freopen("hades.out","w",stdout);
    }
    ios_base::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    int n,m;cin>>n>>m;
    for (int i=1;i<=n;i++) par[i]=i,sz[i]=1;
    for (int i=1;i<=m;i++){
        int u,v,w;cin>>u>>v>>w;
        vec.push_back({u,v,w});
        g[u].push_back(v);g[v].push_back(u);
    }
    sort(vec.begin(),vec.end(),cmp);
    for (Node j:vec){
        gop(j.fi,j.se,j.ba);
    }
    for (int i=1;i<=n;i++){
        int ma=0,ans=1e9;
        for (auto j:g[i]){
            if (dp[max(j,i)]>=ma){
                if (dp[max(j,i)]==ma) ans=min(ans,j);
                else ans=j;
                ma=max(ma,dp[max(j,i)]);
            }
        }
        cout<<ans<<" ";
    }
}

#include<bits/stdc++.h>
#define fi first
#define se second
#define ll long long
using namespace std;
int n;int a,b,c;
namespace sub1{
    void xuly(){
        cout<<a+b+c;
    }
}
namespace sub2{
    void xuly(){
        ll s=a+b+c;
        for(int i=2;i<=n;i++) s+=c;
        cout<<s;
    }
}
namespace full{
    ll t1[1005],t2[1005],t3[1005];
    void xuly(){
        t1[1]=a;t2[1]=a+b;t3[1]=a+b+c;
        for (int i=2;i<=n;i++){
            t1[i]=max(t1[i-1]+a,t2[i-1]+1);
            t2[i]=max(t1[i]+b,t3[i-1]+1);
            t3[i]=t2[i]+c;
//            cout<<t1[i]<<" "<<t2[i]<<" "<<t3[i]<<'\n';
        }
        cout<<t3[n];
    }
}
int main(){
    if (fopen("harvest.inp","r")){
        freopen("harvest.inp","r",stdin);
        freopen("harvest.out","w",stdout);
    }
    ios_base::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    cin>>n;
    cin>>a>>b>>c;
    if (n==1) return sub1::xuly(),0;
    if (a==1&&b==1&&c>2) return sub2::xuly(),0;
    return full::xuly(),0;
}

#include<bits/stdc++.h>
#define fi first
#define se second
#define ll long long
using namespace std;
int n,m;char a[2005],b[2005];
int mp[205],mp1[205];
mt19937 rd(chrono::steady_clock::now().time_since_epoch().count());
#define rand rd
long long Rand(long long l, long long h) {
    long long res=0 ;
    for(int _i=1;_i<=4;_i++) res=(res<<15) ^ (rand() & ((1<<15)-1)) ;
    return l + res % (h - l + 1);
}
namespace sub1{
    bool check(int k,string s,string t){
        string s1="";
        for (int i=n;i>=n-k+1;i--) s1+=s[i-1];
        for (int i=1;i<=n-k;i++) s1+=s[i-1];
        if (s1==t) return true;return false;
    }
    void xuly(){
        vector<int> v;
        int sum=0;
        for (int j=1;j<=10000;j++){
            bool kt=false;int dem=0;v.clear();
            string s="",t="";
            for (int i=1;i<=n;i++) s+=a[i];
            for (int i=1;i<=n;i++) t+=b[i];
            int lu=1e9;
            while (true){
                int k=Rand(1,n);
                v.push_back(k);
                string s1="";
                dem++;
                if (dem>m) break;
                for (int i=n;i>=n-k+1;i--) s1+=s[i-1];
                for (int i=1;i<=n-k;i++) s1+=s[i-1];
                s=s1;if (s1==t) {
                    kt=true;break;
                }
                if (dem+1<=m){
                    for (k=1;k<=n;k++){
                        if (check(k,s,t)) {
                            v.push_back(k);kt=true;break;
                        }
                    }
                }
                if (kt==true) break;
            }
            if (kt==true){
                cout<<v.size()<<'\n';
                for (auto j:v) cout<<j<<" ";
                return;
            }
            sum+=dem;
            if ((sum*n)>100000000) break;
        }
        cout<<"-1";
    }
}
namespace full{
    void xuly(){
        cout<<"-1";
    }
}
int main(){
    if (fopen("shiftrev.inp","r")){
        freopen("shiftrev.inp","r",stdin);
        freopen("shiftrev.out","w",stdout);
    }
    ios_base::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    cin>>n>>m;
    for (int i=1;i<=n;i++) cin>>a[i],mp[int(a[i])-96]++;
    for (int i=1;i<=n;i++) cin>>b[i],mp1[int(b[i])-96]++;
    for (char c='a';c<='z';c++){
        if (mp[int(c)-96]!=mp1[int(c)-96]){
            cout<<"-1";return 0;
        }
    }
    return sub1::xuly(),0;
}

#include<bits/stdc++.h>
#define ll long long
#define fi first
#define se second
#define all(a) a.begin(), a.end()

using namespace std;

const int N = 1e6 + 1;
const int maxn = 1e9 + 1;
const int mod = 1e9 + 7;

#define taskname "hades"
void inp(){
    if(fopen(taskname".inp", "r")){
        freopen(taskname".inp", "w", stdin);
        freopen(taskname".out", "r", stdout);
    }
}

vector<array<int, 3>> edge;
int n, m;

struct DSU{
    vector<int> r;
    ll sum_w;

    DSU(int n){
        r.assign(n + 1, 0);
        for(int i = 1; i <= n; ++i) r[i] = i;
        sum_w = 0;
    }

    int fr(int n){
        return n == r[n] ? n : r[n] = fr(r[n]);
    }

    bool join(int u, int v, int w){
        u = fr(u);
        v = fr(v);

        if(u == v) return false;

        r[u] = v;
        sum_w += w;
        return true;
    }
};

void sub_trau(){
    vector<pair<int, int>> d(n + 1, {maxn, maxn});
    for(auto [x, y, z] : edge){
        DSU f(n + 1);
        for(auto [x1, y1, z1] : edge){
            if(x1 == x && y1 == y && z1 == z) continue;

            bool ok;
            if(x1 == x) ok = f.join(n + 1, y1, z1);
            else if(y1 == y) ok = f.join(x1, n + 1, z1);
            else ok = f.join(x1, y1, z1);
        }

        if(d[x].fi > f.sum_w){
            d[x] = {f.sum_w, y};
        }
        else if(d[x].fi == f.sum_w) d[x].fi = min(d[x].fi, y);

        if(d[y].fi > f.sum_w){
            d[y] = {f.sum_w, x};
        }
        else if(d[y].fi == f.sum_w) d[y].fi = min(d[y].fi, x);
    }

    for(int i = 1; i <= n; ++i) cout << d[i].se << " ";
}

void sub_full(){
    vector<pair<int, int>> v(n + 1, {0, maxn});
    for(auto [x, y, w] : edge){
        if(w > v[x].fi) v[x] = {w, y};
        if(w == v[x].fi) v[x].se = min(v[x].se, y);

        if(w > v[y].fi) v[x] = {w, x};
        if(w == v[y].fi) v[y].se = min(v[y].se, x);
    }

    for(int i = 1; i <= n; ++i) cout << v[i].se << " ";
}

bool cmp(array<int, 3> a, array<int, 3> b){
    return a[2] < b[2];
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    inp();

    cin >> n >> m;

    for(int i = 1; i <= m; ++i){
        int x, y, w; cin >> x >> y >> w;
        edge.push_back({x, y, w});
    }

    sort(all(edge), cmp);

    if(m <= 5000) sub_trau();
    else sub_full();

    return 0;
}

#include<bits/stdc++.h>
#define ll long long
#define fi first
#define se second
#define all(a) a.begin(), a.end()

using namespace std;

const int N = 1e6 + 1;
const int maxn = 1e9 + 1;
const int mod = 1e9 + 7;

#define taskname "harvest"
void inp(){
    if(fopen(taskname".inp", "r")){
        freopen(taskname".inp", "w", stdin);
        freopen(taskname".out", "r", stdout);
    }
}

ll a[N], b[N], c[N];
ll n, t1, t2, t3;

void sub1(){
    cout << t3 + t1 + max(t1, t2);
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    inp();

    cin >> n >> t1 >> t2 >> t3;

    if(n == 1) sub1();
    else{
        if(t1 + max(t1, t2) <= t3) cout << t3 * n + t1 + max(t1, t2);
        else if(t1 == t2 && t2 > t3) cout << 2 * n * t1 + t3;
        else{
            ll d1 = 0, d2 = 0, d3 = 0;
            int c1 = 0, c2 = 0, c3 = 0;
            while(c3 != n){
                d1 += t1;
                c1++;
                if(c2 > 0){
                    c3++;
                    d3 = max({d3, d1, d2}) + t3;
                    c2--,c1--;
                }
                else{
                    c2++;
                    d2 = max(d2, d1) + t2;
                    c1--;
                }

            }
            cout << d3 << '\n';
        }
    }
    return 0;
}

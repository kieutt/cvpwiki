#include<bits/stdc++.h>
#define ll long long
#define fi first
#define se second
#define all(a) a.begin(), a.end()

using namespace std;

const int N = 1e6 + 1;
const int maxn = 1e9 + 1;
const int mod = 1e9 + 7;

#define taskname "shiftrev"
void inp(){
    if(fopen(taskname".inp", "r")){
        freopen(taskname".inp", "w", stdin);
        freopen(taskname".out", "r", stdout);
    }
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    inp();

    cout << -1;

    return 0;
}
